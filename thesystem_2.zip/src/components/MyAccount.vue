<template>
  <div>
    <!-- 搜索框 -->
    <div style=" display: flex;position:relative;margin-left: 30px;">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap">
        <el-form-item label="查看" class="noselect">
          <el-select  v-model="searchContent.searchRange" placeholder="筛选" clearable style="width:120px">
            <el-option v-for="item in chooseRange" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="账号类型" class="noselect">
          <el-select  v-model="searchContent.searchType" placeholder="筛选" clearable style="width:120px">
            <el-option v-for="item in chooseType" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="账户名称" class="noselect">
          <el-input v-model="searchContent.searchAccountName" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        <el-form-item label="ID" class="noselect">
          <el-input v-model="searchContent.searchID" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        <el-form-item label="账号" class="noselect">
          <el-input v-model="searchContent.searchAccount" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        <el-form-item label="信用卡号" class="noselect">
          <el-input v-model="searchContent.searchCardnumber" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        <el-form-item label="充值卡号" class="noselect">
          <el-input v-model="searchContent.searchRechargeCardnumber" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        <el-form-item label="BM" class="noselect">
          <el-input v-model="searchContent.searchBm" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        
        <el-form-item class="noselect">
          <span style="color:#606266;margin-right:12px">日期</span>
          <el-date-picker
            v-model="searchContent.searchDate"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button @click="onSubmit" type="primary" icon="el-icon-search" style="height: 30px;background-color: rgb(65, 181, 132) !important;color:white!important;border-color: white!important "></el-button>
        </el-form-item>
        
        <el-form-item class="noselect">

            <el-button @click="exportExcel" type="info" icon="el-icon-download" style="height: 30px" :disabled="showIf">导出选中项
              <el-badge :value="badge_num" class="item" v-if="showBadge" style="top: -8px;right: -8px;position: absolute;"></el-badge>
            </el-button>
          
        </el-form-item>

        <el-form-item class="noselect">
          <transition name="el-fade-in-linear">
          <el-button type="info" class="multipleSelection_delete_btn" @click="new_form_dialogVisible = true" icon="el-icon-plus" style="height: 30px;color:rgb(245,108,108);background-color:white">申请账号</el-button>
          </transition>
        </el-form-item>

        <el-form-item class="noselect">
          <transition name="el-fade-in-linear">
          <el-button type="info" class="multipleSelection_delete_btn" @click="new_form_Highquota_dialogVisible = true" icon="el-icon-plus" style="height: 30px;color:rgb(245,108,108);background-color:white">申请高额度账号</el-button>
          </transition>
        </el-form-item>
        
      </el-form>
    </div>

    <!-- 表格 -->
    <el-table stripe v-loading="loading" element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 0" border @selection-change="handleSelectionChange_delete">
      <el-table-column type="selection" width="55">
      </el-table-column>
      <el-table-column prop="" label="详情" width="50px">
          <template slot-scope="scope"><!--用于获取当前行的数据-->
            <el-button
              type="text" icon="el-icon-arrow-right"
              size="small"
              @click="tableOpen(scope.row)"
              style="padding-left: 9px;color:#909399"
              ></el-button><!--scope.row表示当前行的数据-->
          </template>
      </el-table-column>
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
          <span>{{(pageIndex - 1) * pagesize + scope.$index + 1}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="_id" label="ID" width="100px">
      </el-table-column>
      <el-table-column prop="account" label="账号" width="300px">
      </el-table-column>
      <el-table-column prop="type" label="类型" width="100px">
      </el-table-column>
      <el-table-column prop="accountName" label="账户名称" width="300px">
      </el-table-column>
      <el-table-column prop="limit" label="限额" width="50px">
      </el-table-column>
      <el-table-column prop="IP" label="登陆IP地区" width="100px">
      </el-table-column>
      <el-table-column prop="getDate" label="拿号时间" width="160px">
      </el-table-column>
      <el-table-column prop="remarks" label="备注" width="160px">
      </el-table-column>
      <el-table-column prop="myRemarks" label="我的备注" width="160px">
        <template slot-scope="scope"><!--用于获取当前行的数据-->
            <el-button
              type="text" icon="el-icon-edit"
              size="small"
              @click="remarks_dialog_open(scope.row)"
              style="padding-left: 9px;color:#909399"
              ></el-button><!--scope.row表示当前行的数据-->
          </template>
      </el-table-column>
      <el-table-column prop="status" label="状态" width="100px">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="220px">
        <template slot-scope="scope">
          <el-button type="info"  size="small" @click="makeOver_btn(scope.row)">转让</el-button><!--scope.row表示当前行的数据-->
          <el-button type="info"  size="small" @click="back_btn(scope.row)">退回</el-button><!--scope.row表示当前行的数据-->
          <el-button type="danger" size="small" @click="deactivate_btn(scope.row)">停用</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination
        :current-page="currentPage4"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400">
      </el-pagination>
    </div>

    <!-- 详情抽屉 -->
    <el-drawer class="noselect" title="详情" :visible.sync="table" direction="rtl" size="600px">
      <el-form ref="makeOver_form"  label-width="100px" label-position="left"  style="padding-left:70px">
        <el-form-item size="small" label="账号：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="密码：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="cookie：" class="noselect" style="position: relative">
          <el-button type="text" icon="el-icon-arrow-left"
              size="small" @click="innerDrawer = true" style="position: absolute;left:0;color:black"></el-button>
        </el-form-item>
        <el-form-item size="small" label="账号BM：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="账户名称" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="广告账号ID：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="信用卡号：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="充值卡号：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="来号日期：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="登陆IP：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="上传时间：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="更新时间：" class="noselect">
        </el-form-item>
        <el-form-item size="small" label="日志记录：" class="noselect">
        </el-form-item>
      </el-form>
      <!-- 嵌套抽屉 -->
      <div>
        <el-drawer
          title="cookie"
          :append-to-body="true"
          :visible.sync="innerDrawer"
          class="noselect"
          size="500px">
        </el-drawer>
      </div>
    </el-drawer>

    <!--申请账号表单  -->
    <el-dialog :visible.sync="new_form_dialogVisible" width="600px" label-width="80px">
      <el-form :rules="rules" ref="new_form" :model="new_form" label-width="80px" label-position="right">
        <el-form-item size="small" label="账号类型" class="noselect" style="margin-right:240px" prop="new_form_type">
          <el-select  v-model="new_form.new_form_type" placeholder="筛选" clearable>
            <el-option v-for="item in chooseType" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="限额" class="noselect" style="margin-right:240px" prop="limit">
          <el-select v-model="new_form.limit" placeholder="筛选" clearable>
            <el-option v-for="item in new_form_limit" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="申请数量" class="noselect" style="margin-right:240px">
          <el-input-number v-model="new_form.applyNumber" :min="1" style="position: absolute;left: 0"></el-input-number>
        </el-form-item>
          <el-button size="small" type="primary" @click="submitForm('new_form')" class="formSubmitBtn" style="margin-right: 340px;">确 定</el-button>
      </el-form>
    </el-dialog>

    <!-- 申请高额度账号表单 -->
    <el-dialog :visible.sync="new_form_Highquota_dialogVisible" width="800px" label-width="80px">
      <el-form :rules="rules" ref="new_form_Highquota" :model="new_form_Highquota" label-width="80px" label-position="right">
        <el-form-item size="small" label="账号类型" class="noselect" style="margin-right:440px" prop="new_form_type_highquota">
          <el-select v-model="new_form_Highquota.new_form_type_highquota" placeholder="筛选" clearable>
            <el-option v-for="item in chooseType" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="限额" class="noselect" style="margin-right:440px" prop="limit_highquota">
          <el-select v-model="new_form_Highquota.limit_highquota" placeholder="筛选" clearable>
            <el-option v-for="item in new_form_limit_highquota" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="来号批次" class="noselect" style="margin-right:440px" prop="batch_highquota">
          <el-select v-model="new_form_Highquota.batch_highquota" placeholder="筛选" clearable>
            <el-option v-for="item in new_form_highquota_batch" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="申请数量" class="noselect" style="margin-right:440px">
          <el-input-number v-model="new_form_Highquota.applyNumber_highquota" :min="1" style="position: absolute;left: 0"></el-input-number>
        </el-form-item>
        <el-form-item size="small" label="推广" class="noselect" style="margin-right:440px" prop="extension_highquota">
          <el-select v-model="new_form_Highquota.extension_highquota" placeholder="筛选" clearable>
            <el-option v-for="item in new_form_highquota_extension" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
        <el-button size="small" type="primary" @click="submitForm('new_form_Highquota')" class="formSubmitBtn" style="margin-right: 540px;">确 定</el-button>

      <el-table v-loading="loading" element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData_Highquota" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 25px" border><!--@selection-change="handleSelectionChange_delete"-->
      <el-table-column prop="type" label="类型">
      </el-table-column>
      <el-table-column prop="limit" label="限额">
      </el-table-column>
      <el-table-column prop="batch" label="批次">
      </el-table-column>
      <el-table-column prop="number" label="数量">
      </el-table-column>
    </el-table>
    </el-dialog>

    <!--转让表单  -->
    <el-dialog :visible.sync="makeOver_form_dialogVisible" width="500px">
      <el-form ref="makeOver_form" :rules="rules" :model="makeOver_form" label-width="100px" label-position="right">
        <el-form-item size="small" label="账号名称：" class="noselect">
          <p style="text-align:left">{{this.makeOver_form.makeOver_accountname}}</p>
        </el-form-item>
        <el-form-item size="small" label="限额：" class="noselect">
          <p style="text-align:left">{{this.makeOver_form.makeOver_quota}}</p>
        </el-form-item>
        <el-form-item size="small" label="转出用户：" class="noselect" style="margin-right:200px" prop="makeOver_user_input">
          <el-select v-model="makeOver_form.makeOver_user_input" placeholder="筛选" clearable>
            <el-option v-for="item in makeOver_user" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
        <el-button size="small" type="primary" @click="submitForm('makeOver_form')" class="formSubmitBtn" style="margin-right: 200px;">确 定</el-button>
    </el-dialog>

    <!-- 退回表单 -->
    <el-dialog :visible.sync="back_form_dialogVisible" width="500px">
      <el-form ref="back_form" :rules="rules" :model="back_form" label-width="80px" label-position="right">
        <el-form-item size="small" label="申请理由" class="noselect" style="margin-right:20px" prop="back_reason">
          <el-input v-model="back_form.back_reason" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-form>
        <el-button size="small" type="primary" @click="submitForm('back_form')" class="formSubmitBtn" style="margin-right: 240px;">确 定</el-button>
    </el-dialog>

    <!-- 停用表单 -->
    <el-dialog :visible.sync="deactivate_form_dialogVisible" width="500px">
      <el-form ref="deactivate_form" :rules="rules" :model="deactivate_form" label-width="100px" label-position="right">
        <el-form-item size="small" label="账号名称：" class="noselect">
          <p style="text-align:left">{{this.deactivate_form.deactivate_accountname}}</p>
        </el-form-item>
        <el-form-item size="small" label="停用截图：" class="noselect" style="margin-right:300px;position:relative">
          <span style="color:red;position:absolute;left:-92px">*</span>
          <el-upload
          required
            class="avatar-uploader"
            action=''
            :show-file-list="false"
            :auto-upload="false"
            :on-change="getFile">
            <img v-if="imageUrl" :src="imageUrl" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
        <el-button size="small" type="primary" @click="submitForm_pic('deactivate_form')" class="formSubmitBtn" style="margin-right: 200px;">确 定</el-button>
    </el-dialog>

    <!-- 我的备注表单 -->
    <el-dialog :visible.sync="remarks_dialog_dialogVisible" width="500px">
      <el-form ref="remarks_dialog"  :model="remarks_dialog" label-width="80px" label-position="right">
        <el-form-item size="small" label="我的备注" class="noselect" style="margin-right:20px" prop="back_reason">
          <el-input v-model="remarks_dialog.remarks" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-form>
        <el-button size="small" type="primary" @click="submitForm('remarks_dialog')" class="formSubmitBtn" style="margin-right: 240px;">确 定</el-button>
    </el-dialog>
  </div>
</template>

<script>
import { export_json_to_excel } from '../Export2Excel.js'
  export default {
    data() {
      return {
        //表单图片
        imageUrl: '',
        //红点
        badge_num : null,
        showBadge: false,
        //我的备注
        remarks_dialog_dialogVisible: false,
        remarks_dialog: {
          remarks: '',
          id: null
        },      
        // 详情抽屉
        someData1:null,// 临时数据 懒得造
        someData2:null,
        someData3:null,
        someData4:null,
        table: false,
        innerDrawer: false,
        // 批量删除
        multipleSelection_delete:null,//选中项
        showIf: true,
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载界面显示与否
        loading: true,
        // excel数据
        excelData: null,
        // 展示数据
        ShowTableData: null,
        ShowTableData_Highquota: null,
        // 原始数据
        tableData: null,
        // 搜索账号类型选项
        chooseType: null,
        chooseRange: ['全部','正常','失效'],
        // 搜索输入框记录
        searchContent: {
          searchRange: null,
          searchType: null,
          searchAccountName: null,
          searchID: null,
          searchAccount: null,
          searchCardnumber: null,
          searchRechargeCardnumber: null,
          searchBm: null,
          searchDate: null,
        },
        //表单的显示
        new_form_dialogVisible :false,
        new_form_Highquota_dialogVisible:false,
        makeOver_form_dialogVisible: false,
        back_form_dialogVisible: false,
        deactivate_form_dialogVisible: false,
        //表单提交内容
        new_form: {//申请账号
          new_form_type: '',
          limit: '',
          applyNumber: ''
        },
        new_form_Highquota: {//申请高额账号
          new_form_type_highquota: null,
          limit_highquota: null,
          applyNumber_highquota: null,
          batch_highquota: null,
          extension_highquota: null
        },
        makeOver_form: {//转让
          makeOver_accountname: null,
          makeOver_quota: null,
          makeOver_user_input: null,
          makeOver_id: null,
        },
        back_form: {//退回
          back_id: null,
          back_reason: null,
        },
        //停用表单的数据
        deactivate_form: {
          deactivate_id : null,
          deactivate_accountname: null,
          proofImage : '',
        },
        // 表单选项
        new_form_limit: ['25', '50'],
        new_form_limit_highquota: ['其他',25, 50,'半限额','不限额'],
        new_form_highquota_extension: null,
        new_form_highquota_batch: null,
        makeOver_user: null,
        //校验规则
        rules: {
          // 申请账号校验规则
          new_form_type: [
            { required: true, message: '请选择账户类型', trigger: 'change' }
          ],
          limit: [
            { required: true, message: '请输入限额', trigger: 'change' }
          ],

          //申请高额度账号表单校验规则
          new_form_type_highquota: [
            { required: true, message: '请选择账户类型', trigger: 'change' }
          ],
          limit_highquota: [
            { required: true, message: '请输入限额', trigger: 'change' }
          ],
          batch_highquota: [
            { required: true, message: '请输入批次', trigger: 'change' }
          ],
          extension_highquota: [
            { required: true, message: '请选择推广人员', trigger: 'change' }
          ],

          //转让表单校验规则
          makeOver_user_input: [
            { required: true, message: '请输入转让人员', trigger: 'change' }
          ],

          //退回表单校验规则
          back_reason: [
            { required: true, message: '请输入退回理由', trigger: 'blur' }
          ]
        }
      }
    },

    created() {
      // 执行网络请求
      this.fetchOption()
      //获取表单选项及表格数据
      this.fetch_form_data()
    },

    methods: {
      //  -----------------------------------------------------------
      // 图片上传相关
      getFile(file) {
        console.log(file);
        var isJPG_PNG = ['image/jpeg','image/png']
        var jin = isJPG_PNG.indexOf(file.raw.type) !== -1
        // const isLt2M = file.size / 1024 / 1024 < 2;
        if (!jin) {
          this.$message.error('上传图片只能是 JPG/PNG 格式!');
          }
        else {
          this.handleAvatarSuccess(file)
          this.getBase64(file.raw).then(res => {
            const params = res.split(',')
            console.log(params, 'params')
            if (params.length > 0) {
              this.deactivate_form.proofImage = params[1]
            }
          })
        }
      },
      //显示缩略图
      handleAvatarSuccess(file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      // 获取图片转base64
      getBase64(file) {
        return new Promise(function (resolve, reject) {
          const reader = new FileReader()
          let imgResult = ''
          reader.readAsDataURL(file)
          reader.onload = function () {
            imgResult = reader.result
          }
          reader.onerror = function (error) {
            reject(error)
          }
          reader.onloadend = function () {
            resolve(imgResult)
          }
        })
      },
      //  -----------------------------------------------------------
      // 导出数据为表格
      exportExcel() {
      var tHeader = ['系统ID', '账号', '类型','账户名称','限额','来号批次','推广','备注','状态']
      var filterVal = ['_id', 'account','type','accountname','limit','comebatch','extension','remarks','status']
      var time = this.getCurentTime()
      var filename = `${time}`
      var data = this.formatJson(filterVal, this.excelData)
      export_json_to_excel({
        header: tHeader,
        data,
        filename
      })
      this.$refs.multipleTable.clearSelection();
    },
      formatJson(filterVal, excelData) {
        return excelData.map(v => {
            return filterVal.map(j => {
                    return v[j]
                })
            }
        )
      },
      //获取当前时间，格式YYYY-MM-DD
      getNowFormatDate() {
          var date = new Date();
          var seperator1 = "-";
          var year = date.getFullYear();
          var month = date.getMonth() + 1;
          var strDate = date.getDate();
          if (month >= 1 && month <= 9) {
              month = "0" + month;
          }
          if (strDate >= 0 && strDate <= 9) {
              strDate = "0" + strDate;
          }
          var currentdate = year + seperator1 + month + seperator1 + strDate;
          return currentdate;
      },
      getCurentTime(isTime=true) {
        var now = new Date();
        var clock = "";
        var year = now.getFullYear();       // 年
        clock += year + "-";
        var month = now.getMonth() + 1;     // 月
        if (month < 10) {
            clock += "0";
        }
        clock += month + "-";
        var day = now.getDate();            // 日
        if (day < 10) {
            clock += "0";
        }
        if (isTime == true) {
            clock += day + " ";
            var hh = now.getHours();            // 时
            if (hh < 10) {
                clock += "0";
            }

            clock += hh + "-";
            var mm = now.getMinutes();     // 分
            if (mm < 10) {
                clock += '0';
            }
            clock += mm + "-";
            var ss = now.getSeconds();     // 秒
            if (ss < 10) {
                clock += '0';
            }
            clock += ss;
        }
        if (isTime == false) {
            clock += day;
        }
        // console.log(clock);
        return clock;
    },
      // -----------------------------------------------------------
      //我的备注表单
      remarks_dialog_open(e) {
        console.log(e);
        this.remarks_dialog.id = e._id
        this.remarks_dialog_dialogVisible = true
      },
      // -----------------------------------------------------------
      //复制
      onCopy(e){
        this.$message({
          message:'复制成功！',
          type:'success'
        })
      },
      
      onError(e){
        this.$message({
          message:'复制失败！',
          type:'error'
        })
      },
      // -----------------------------------------------------------
      //表单提交
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
        });
      },
      // -----------------------------------------------------------
      //表单提交-图片
      submitForm_pic(formName) {
        this.$refs[formName].validate((valid) => {
          if (this[formName].proofImage === '') {
            this.$message.error('请上传停用截图');
          } else {
            if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
          }
        });
      },
      //-------------------------------------------------------------
      //停用
      deactivate_btn(e) {
        this.deactivate_form.deactivate_id = e._id
        this.deactivate_form.deactivate_accountname = e.accountName
        this.deactivate_form_dialogVisible = true
      },
      //-------------------------------------------------------------
      //退回
      back_btn(e) {//点击退回按钮
        this.back_form_dialogVisible = true
        this.back_form.back_id = e._id
      },
      //-------------------------------------------------------------
      // 转让
      makeOver_btn(e) {//点击转让按钮
        this.makeOver_form.makeOver_accountname = e.accountName
        this.makeOver_form.makeOver_id = e._id
        this.makeOver_form.makeOver_quota = e.limit
        this.makeOver_form_dialogVisible = true
      },
      //--------------------------------------------------------------
      // 多项选择
      handleSelectionChange_delete(val) {//有选中项目时触发
        if (val.length === 0) {
          this.showBadge = false
        } else {
          this.showBadge = true
          this.badge_num = val.length
        }
        console.log(val); 
        this.excelData = val
        this.multipleSelection_delete = val;
        if (val != '') {
          this.showIf = false
        } else {
          this.showIf = true
        }
      },
      //--------------------------------------------------------------
      // 权限详情
      tableOpen(e) {
        console.log(e);
        this.table = true
        this.someData1 = e._id
        this.someData2 = e.date
        this.someData3 = e.department
        this.someData4 = e.post
      },
      //--------------------------------------------------------------
      // 搜索选项获取
      fetchOption() {
        this.$http.get('/accountmanagement.json').then((res) => {// 获取数据
          // this.tableData = res.data.RecyclingApproval//保留原数据
          // this.ShowTableData = this.tableData//原数据赋值给展示的表格数据
          //根据数据填充下拉选项-账号类型
          this.chooseType = res.data.accountFilter
          //数据完成展示后取消加载页面
          this.loading = false
        })
      },
      //获取表单选项及表格数据
      fetch_form_data() {
        this.$http.get('/accountmanagement.json').then((res) => {// 获取数据
          this.ShowTableData_Highquota = res.data.new_form_highquota_tabledata
          this.new_form_highquota_extension = res.data.new_form_highquota_extension
          this.new_form_highquota_batch = res.data.new_form_highquota_batch
          this.makeOver_user = res.data.makeOver_user
        })
      },
      //--------------------------------------------------------------
      //搜索提交
      onSubmit() {
        this.loading = true
        setTimeout(()=> {
          this.fetchData()
        },1000)
      },
      fetchData() {
        this.$http.get('/accountmanagement.json').then((res) => {// 获取数据
          this.ShowTableData = res.data.myAccountData//保留原数据
          //数据完成展示后取消加载页面
          this.loading = false
        })
      }
    },
  }
</script>

<style scoped>
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: rgb(65, 181, 132);
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
      color: rgb(65, 181, 132) !important;
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
  .el-button--primary {
      color: rgb(65, 181, 132) !important;
      background-color: #fff !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(65, 181, 132) !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--info {
      color: #606266 !important;
      background-color: #fff !important;
      border-color: rgb(220, 223, 230) !important;
  }
  .el-button--info:hover {
    box-shadow: rgb(0 21 41 / 8%) 2px 2px 4px;
  }
  .el-select {
    display: block!important;
  }

</style>
