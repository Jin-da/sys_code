<template>
  <div>
    <!-- 搜索框 -->
    <div style=" display: flex;position:relative;margin-left: 30px;">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap">
        <el-form-item label="账号类型" class="noselect">
          <el-select  @change="utils_run" v-model="searchType" placeholder="筛选" clearable style="width:120px">
            <el-option v-for="item in chooseType" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="推广" class="noselect">
          <el-select @change="utils_run" v-model="searchExtension" placeholder="筛选" clearable style="width:120px">
            <el-option v-for="item in chooseExtension" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
                <el-form-item label="账号" class="noselect">
          <el-input @change='utils_run' v-model="searchAccount" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
                <el-form-item label="信用卡号" class="noselect">
          <el-input @change='utils_run' v-model="searchCardNumber" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
                <el-form-item label="充值卡号" class="noselect">
          <el-input @change='utils_run' v-model="searchRechargeCardnumber" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
                <el-form-item label="BM" class="noselect">
          <el-input @change='utils_run' v-model="searchBm" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        <el-form-item label="来号日期" class="noselect">
          <el-input @change='utils_run' v-model="searchComeDate" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
                <el-form-item label="来号批次" class="noselect">
          <el-input @change='utils_run' v-model="searchBatch" placeholder="请输入内容" clearable style="width:120px">
          </el-input>
        </el-form-item>
        
        <el-form-item class="noselect">
          <span style="color:#606266;margin-right:12px">日期</span>
          <el-date-picker
          @change="utils_run"
            v-model="searchDate"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd"
          >
          </el-date-picker>
        </el-form-item>
        <!-- <el-form-item>
          <el-button @click="onSubmit" type="primary" icon="el-icon-search" style="height: 30px;background-color: rgb(65, 181, 132) !important;color:white!important;border-color: white!important "></el-button>
        </el-form-item> -->
        <el-form-item class="noselect">
          <el-button type="info" icon="el-icon-download" style="height: 30px" :disabled="showIf">导出选中项
              <el-badge :value="badge_num" class="item" v-if="showBadge" style="top: -8px;right: -8px;position: absolute;"></el-badge>
          </el-button>
        </el-form-item>
        <el-form-item class="noselect">
          <transition name="el-fade-in-linear">
          <el-button type="primary" class="multipleSelection_delete_btn" v-show="multipleSelectionFlag_delete" @click="multiPass()" icon="el-icon-check" style="height: 30px;color:rgb(245,108,108);background-color:white">批量通过</el-button>
          </transition>
        </el-form-item>
        <el-form-item class="noselect">
          <transition name="el-fade-in-linear">
          <el-button type="danger" class="multipleSelection_delete_btn" v-show="multipleSelectionFlag_delete" @click="multiDelete()" icon="el-icon-close" style="height: 30px;color:rgb(245,108,108);background-color:white">批量拒绝</el-button>
          </transition>
        </el-form-item>
      </el-form>
    </div>

    <!-- 表格 -->
    <el-table stripe v-loading="loading" element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 0" border @selection-change="handleSelectionChange_delete">
      <el-table-column type="selection" width="55">
      </el-table-column>
      <el-table-column prop="" label="详情" width="50px">
          <template slot-scope="scope"><!--用于获取当前行的数据-->
            <el-button
              type="text" icon="el-icon-arrow-right"
              size="small"
              @click="tableOpen(scope.row)"
              style="padding-left: 9px;color:#909399"
              ></el-button><!--scope.row表示当前行的数据-->
          </template>
      </el-table-column>
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
          <span>{{(pageIndex - 1) * pagesize + scope.$index + 1}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="_id" label="ID" width="100px">
      </el-table-column>
      <el-table-column prop="account" label="账号" width="250px">
      </el-table-column>
      <el-table-column prop="reason" label="申请理由" width="200px">
      </el-table-column>
      <el-table-column prop="extension" label="推广" width="100px">
      </el-table-column>
      <el-table-column prop="type" label="类型" width="100px">
      </el-table-column>
      <el-table-column prop="ip" label="登陆IP地区" width="100px">
      </el-table-column>
      <el-table-column prop="batch" label="来号批次">
      </el-table-column>
      <el-table-column prop="date" label="拿号时间" width="160px">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="120px">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-check" size="small" @click="pass(scope.row)"></el-button><!--scope.row表示当前行的数据-->
          <el-button type="danger" icon="el-icon-close" size="small" @click="remove(scope.row)"></el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination
        :current-page="currentPage4"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400">
      </el-pagination>
    </div>

    <!-- 详情抽屉 -->
    <el-drawer title="详情" :visible.sync="table" direction="rtl" size="50%">
      <span>{{this.someData1}}</span><br>
      <span>{{this.someData2}}</span><br>
      <span>{{this.someData3}}</span><br>
      <span>{{this.someData4}}</span><br>
    </el-drawer>
  </div>

</template>

<script>
  import utils from '../utils'//引入过滤方法
  export default {
    data() {
      return {
        //红点
        badge_num : null,
        showBadge: false,
        // 详情抽屉
        someData1:'',// 临时数据 懒得造
        someData2:'',
        someData3:'',
        someData4:'',
        table: false,
        // 批量删除
        multipleSelectionFlag_delete:false,//删除按钮出现与否
        multipleSelection_delete:'',//选中项
        showIf: true,
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载界面显示与否
        loading: true,
        // 过滤后数据
        ShowTableData: [],
        // 原始数据
        tableData: [],
        // 搜索推广选项
        chooseExtension: [],
        // 搜索账号类型选项
        chooseType: [],
        // 搜索输入框记录
        searchCardNumber: '',
        searchExtension: '',
        searchAccount: '',
        searchType: '',
        searchRechargeCardnumber: '',
        searchBm: '',
        searchBatch: '',
        searchComeDate: '',
        searchDate: [],
        middleSearchDate: ''//日期的中间转换变量(当有日期筛选时需要使用)
      }
    },

    created() {
      // 执行网络请求
      setTimeout(()=> {
        this.fetch()
      },1000)
      // this.fetch()
    },

    methods: {
      //--------------------------------------------------------------
      // 搜索-顺序执行筛选方法数组中的方法(input框code为0;日期筛选code为1,无code默认为下拉筛选框)
      utils_run() {
        var _this = this
        this.ShowTableData = this.tableData// 触发搜索前重新赋值原始数据
        utils.dateToString(_this)//当有日期筛选时需要使用-优先执行

        utils.multiplexFilter(_this,this.searchType, 'type')
        utils.multiplexFilter(_this,this.searchExtension, 'extension')

        utils.multiplexFilter(_this,this.searchCardNumber, 'cardnumber', 0)
        utils.multiplexFilter(_this,this.searchAccount, 'account', 0)
        utils.multiplexFilter(_this,this.searchRechargeCardnumber, 'Rechargecardnumber', 0)
        utils.multiplexFilter(_this,this.searchBatch, 'batch', 0)
        utils.multiplexFilter(_this,this.searchBm, 'bm', 0)
        // utils.multiplexFilter(_this,this.searchComeDate, 'comedate', 0)

        utils.multiplexFilter(_this,this.middleSearchDate, 'date', 1)
      },
      //--------------------------------------------------------------
      // 批量删除(待添加async await)
      handleSelectionChange_delete(val) {//有选中项目时触发
        if (val.length === 0) {
          this.showBadge = false
        } else {
          this.showBadge = true
          this.badge_num = val.length
        }
          this.multipleSelection_delete = val;
          this.multipleSelectionFlag_delete = true;
          if (this.multipleSelection_delete.length == 0) {   
            // 如不进行判断则勾选完毕后批量删除按钮还是会在
            this.multipleSelectionFlag_delete = false;
          }
          if (val != '') {
            this.showIf = false
          } else {
            this.showIf = true
          }
      },
      multiDelete() {//点击批量删除时触发
        let checkArr = this.multipleSelection_delete;//multipleSelection存储了勾选到的数据
        let params = [];//传给后端的删除项id
        let showDeleteItems = []
        checkArr.forEach(function (item) {     
          params.push(item._id);       // 添加所有需要删除数据的id到一个数组，post提交过去
          showDeleteItems.push(item._id)
        });
        this.$confirm(`是否批量拒绝ID为: ${showDeleteItems} 的回收申请`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            this.$message({
              type: "success",
              message: "删除成功(等待接口)",
            });
            // await this.$http.delete(`rest/ads/${row._id}`);
            // this.$message({
            //   type: "success",
            //   message: "删除成功!",
            // });
            // this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
        // 有接口时解开
        // let self = this;
          // 有接口时解开
        //  $http即是axios，可以在main.js里面设置 Vue.prototype.$http = axios;
        // this.$http.post('/fashion/multiDelete', params).then(function (res) {
        //   if (res.data.status == '1') {
        //     self.$message({
        //       message: '删除成功',
        //       type: 'success'
        //     });
        //   }
        //   self.getFashionList(1, 1, 5);
        // })
      },

      multiPass() {//点击批量通过时触发
        let checkArr = this.multipleSelection_delete;//multipleSelection存储了勾选到的数据
        let params = [];//传给后端的删除项id
        let showDeleteItems = []
        checkArr.forEach(function (item) {     
          params.push(item._id);       // 添加所有需要删除数据的id到一个数组，post提交过去
          showDeleteItems.push(item._id)
        });
        this.$confirm(`是否批量通过ID为: ${showDeleteItems} 的回收申请`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            this.$message({
              type: "success",
              message: "操作成功(等待接口)",
            });
            // await this.$http.delete(`rest/ads/${row._id}`);
            // this.$message({
            //   type: "success",
            //   message: "删除成功!",
            // });
            // this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
        // 有接口时解开
        // let self = this;
          // 有接口时解开
        //  $http即是axios，可以在main.js里面设置 Vue.prototype.$http = axios;
        // this.$http.post('/fashion/multiDelete', params).then(function (res) {
        //   if (res.data.status == '1') {
        //     self.$message({
        //       message: '删除成功',
        //       type: 'success'
        //     });
        //   }
        //   self.getFashionList(1, 1, 5);
        // })
      },
      //--------------------------------------------------------------
      // 权限详情
      tableOpen(e) {
        this.table = true
        this.someData1 = e._id
        this.someData2 = e.date
        this.someData3 = e.department
        this.someData4 = e.post
      },
      //--------------------------------------------------------------
      // 数据获取
      fetch() {
        this.$http.get('/accountmanagement.json').then((res) => {// 获取数据
        this.tableData = res.data.RecyclingApproval//保留原数据
        this.ShowTableData = this.tableData//原数据赋值给展示的表格数据
        
        //根据数据填充下拉选项-账号类型
        this.tableData.forEach(item => {
          this.chooseType.push(item.type)
        })
        this.chooseType = [...new Set(this.chooseType)]

        //根据数据填充下拉选项-推广
        this.tableData.forEach(item => {
          this.chooseExtension.push(item.extension)
        })
        this.chooseExtension = [...new Set(this.chooseExtension)]

        //数据完成展示后取消加载页面
        this.loading = false
      })

      },
      //--------------------------------------------------------------
      // 拒绝单项
      async remove(row) {
        this.$confirm(`是否拒绝: ${row._id}`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            await this.$http.delete(`rest/ads/${row._id}`);
            this.$message({
              type: "success",
              message: "操作成功",
            });
            this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消",
            });
          });
      },
      // 通过单项
      async pass(row) {
        this.$confirm(`是否同意: ${row._id}`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            await this.$http.delete(`rest/ads/${row._id}`);
            this.$message({
              type: "success",
              message: "操作成功",
            });
            this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消",
            });
          });
      },
    },
  }
</script>

<style scoped>
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
      color: rgb(65, 181, 132) !important;
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
  .el-button--primary {
      color: rgb(65, 181, 132) !important;
      background-color: #fff !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(65, 181, 132) !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--info {
      color: #606266 !important;
      background-color: #fff !important;
      border-color: rgb(220, 223, 230) !important;
  }
      .el-button--info:hover {
      box-shadow: rgb(0 21 41 / 8%) 2px 2px 4px;
  }

</style>
