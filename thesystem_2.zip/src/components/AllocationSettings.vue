<template>
<div>分配设置</div>
</template>

<script>
export default {
  props: {
  }
}
</script>

<style scoped lang="scss">

</style>
