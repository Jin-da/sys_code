<template>
  <div>
    <!-- 搜索框 -->
    <div style="display: flex;position:relative;min-width:915px">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display: flex; flex-wrap: wrap" :disabled="loading">
        <el-form-item class="noselect">
          <el-button class="info_btn" @click="newPage()" type="info" style="height: 30px; position: relative; margin-top: 32px">创建审核页</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 卡片 -->
    <div class="card-div" v-loading="loading">
        <el-card class="list" v-for="(item,index) in this.ShowTableData" :key="index" :body-style="{ padding: '0px' }">
          <el-image @click="clickImg(item['content']['value'])" style="cursor: pointer;" :src="item['content']['previewImg']" class="image" lazy></el-image>
          <div style="padding: 14px;">
            <div style="text-align:left;font-weight: bolder;font-size: 15px;">{{item['content']['text']}}</div>
            <div class="bottom clearfix" style="position:relative">
              <div class="des_div">{{item['content']['value']}}</div>
              <el-button type="text" class="button" @click="edit(item)">编辑</el-button>
            </div>
          </div>
        </el-card>
        <div v-for="item in this.ShowTableData" :key="item['value']" style="width:280px;heigt:370px;"></div>
    </div>
    <!-- 编辑审核页表单 -->
    <el-dialog :close-on-click-modal="false" title="编辑审核页" :visible.sync="edit_form_dialogVisible" width="450px">
      <el-form label-width="100px" label-position="right" v-loading="edit_form_loading">
        <el-row>
          <el-col :span="24">
            <el-form-item label="审核页名称" class="noselect" style="margin-right: 40px" prop="ad_title">
              <el-input placeholder="可输入任意标题" v-model="edit_form['content']['text']" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="指向文件" class="noselect" style="margin-right: 40px" prop="ad_title">
              <el-input placeholder="例：iceboo" v-model="edit_form['content']['value']" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="图片路径" class="noselect" style="margin-right: 40px" prop="ad_title">
              <el-input placeholder="例：/static/img/previewImg/jf/jf-line-33.webp" v-model="edit_form['content']['previewImg']" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-button size="small" type="primary" @click="edit_form_submit()" class="formSubmitBtn" style="margin-right: -270px" >确 定</el-button>
      </el-form>
    </el-dialog>

    <!-- 创建审核页表单 -->
    <el-dialog :close-on-click-modal="false" title="创建审核页" :visible.sync="new_form_dialogVisible" width="450px">
      <el-form label-width="100px" label-position="right" v-loading="new_form_loading">
        <el-row>
          <el-col :span="24">
            <el-form-item label="审核页名称" class="noselect" style="margin-right: 40px" prop="ad_title">
              <el-input placeholder="可输入任意标题" v-model="new_form['content']['text']" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="指向文件" class="noselect" style="margin-right: 40px" prop="ad_title">
              <el-input placeholder="例：iceboo" v-model="new_form['content']['value']" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="图片路径" class="noselect" style="margin-right: 40px" prop="ad_title">
              <el-input placeholder="例：/static/img/previewImg/jf/jf-line-33.webp" v-model="new_form['content']['previewImg']" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-button size="small" type="primary" @click="new_form_submit()" class="formSubmitBtn" style="margin-right: -270px" >确 定</el-button>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import utils from '../utils'
export default {
  data() {
    return {
      options: null,
      uid:null,
      // 回流key
      key: 0,
      // 加载界面显示与否
      loading: true,
      // 过滤后数据
      ShowTableData: [],
      // 原始数据
      tableData: [],
      // 按钮权限
      buttonAuthority: {
        searchGroupAuthority: true,
        searchNameAuthority: true,
        searchObjectAuthority: true,
      },
      // 编辑审核页
      edit_form_dialogVisible: false,
      edit_form: {
        content: {
          disable: null,
          previewImg: null,
          text: null,
          value: null,
        },
        id: null,
      },
      // 创建审核页
      new_form_dialogVisible:false,
      new_form: {
        content: {
          disable: null,
          previewImg: 'static/img/examinedImg/wikiPitaya.webp',
          text: null,
          value: null,
        },
      },
      edit_form_loading:false,
      new_form_loading:false
    };
  },

  created() {
    this.getUid()
    this.fetch();
  },

  methods: {
    handleUpdateClick() {// 回流
      this.key += 1 
    },
    clickImg(e) {//图片跳转预览
      window.open(`http://new.vgdg67.cn/safePage/${e}`)
    },
    getUid() { // 获取用户uid
      this.uid = localStorage.getItem("uid")
    },
    async fetch() {// 数据获取
      this.loading = true
      await this.$http.get("/index.php/index/Landingpage/safeList/").then((res) => {
        res.data["data"].forEach(e=> {
          e["content"] = JSON.parse(e["content"])
          e["content"]["previewImg"] = `https://new.vgdg67.cn/${e["content"]["previewImg"]}`
        })
          this.tableData = res.data["data"];
          this.ShowTableData = this.tableData;
          this.loading = false;
      });
    },
    edit(e) {
      this.edit_form = utils.deepClone(e)
      this.edit_form_dialogVisible = true
    },
    async edit_form_submit() {
      let formData = new FormData()
      this.edit_form["content"]["previewImg"] = this.edit_form["content"]["previewImg"].replace('https://new.vgdg67.cn/','')
      var data = JSON.stringify(this.edit_form)
      formData.append('data',data)
      this.edit_form_loading = true
      await this.$http.post('/index.php/index/Landingpage/editSafe/',formData).then((res) => {
        if (res.data["code"] === 200) {
          this.edit_form["content"]["previewImg"] = `https://new.vgdg67.cn/${this.edit_form["content"]["previewImg"]}`
          this.edit_form_dialogVisible = false
          this.fetch()
            this.$message.success(`${res.data["data"]}`)
        } else {
          this.$message.error(`${res.data["data"]}`)
        }
        this.edit_form_loading = false
      })
    },
    newPage() {
      this.new_form_dialogVisible = true
    },
    async new_form_submit() {
      this.new_form_loading = true
      let formData = new FormData()
      var data = JSON.stringify(this.new_form)
      formData.append('data',data)
      await this.$http.post('/index.php/index/Landingpage/addSafe/',formData).then((res)=>{
        if (res.data["code"] === 200) {
          this.new_form_dialogVisible = false
          this.fetch()
          this.$message.success(`${res.data["data"]}`)
        } else {
          this.$message.error(`${res.data["data"]}`)
        }
      })
    }
  },
};
</script>

<style scoped>
.el-dropdown-menu__item {
  text-align: center;
}

.is-active {
  background-color: white !important;
}
.el-select-dropdown__item.selected {
  /* color: rgb(65, 181, 132) !important; */
  font-weight: 700;
}
.el-main {
  line-height: 20px !important;
}
.el-button--primary {
  color: rgb(41, 42, 45) !important;
  background-color: #fff !important;
  border-color: rgb(41, 42, 45) !important;
}
.el-button--primary:hover {
  color: white !important;
  background-color: rgb(77, 77, 77) !important;
  border-color: rgb(77, 77, 77) !important;
}
.el-select {
  display: block !important;
}
.el-button.is-disabled {
  color: #C0C4CC!important;
}
.el-button.is-disabled.el-button--text {
  color: #C0C4CC!important;;
}
  .time {
    font-size: 13px;
    color: #999;
  }
  
  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }

  .button {
    padding: 0;
    right: 0;
    bottom: 0;
    position: absolute;
  }

  .image {
    width: 250px;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  
  .clearfix:after {
    clear: both
  }
  .card-div {
    min-height: 500px;
    width: 90%;
    display: flex;
    flex-wrap: wrap;
    margin: auto!important;
    justify-content: space-evenly;
  }
  .el-card {
    width: 250px;
    margin:30px 15px 50px 15px;
  }
  .des_div {
    text-align: left;
    line-height: 20px;
    margin-bottom: 10px;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .info_btn {
  background-color: #353639!important;
  color: white!important;
  border-color: #353639!important;
}
.info_btn:hover {
  background-color: #4D4D4D!important;
  border-color: #4D4D4D!important;
}
.el-button--info.is-disabled:hover{
  color: grey!important;
}
.el-button--info.is-disabled {
  border-color: grey!important;
  color:grey!important;
  background-color: white!important;
}

</style>
