<template>
  <div >
    <!-- 搜索框 -->
    <div style="display: flex;position:relative;min-width:500px">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display: flex; flex-wrap: wrap;width:100%;justify-content: space-between" :disabled="loading">
        <el-form-item class="noselect">
          <el-input v-model="searchParams.accurateSearch" placeholder="搜索域名" clearable style="width: 200px;margin-right:10px"></el-input>
          <el-button icon="el-icon-search" @click="search" plain style="height: 30px; position: relative; margin-top: 32px" >搜索</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 数量显示 -->
    <div style="width:100%;height:25px;margin-bottom:8px;text-align:left;min-width:330px">
      <div style="display:inline-block;margin-right:20px"><p style="display:inline-block;font-weight: bolder;">域名总数：</p>{{this.statistics.sum}}</div>
      <div style="display:inline-block;margin-right:20px"><p style="display:inline-block;font-weight: bolder;">使用总数：</p>{{this.statistics.use_in}}</div>
      <div style="display:inline-block;margin-right:20px"><p style="display:inline-block;font-weight: bolder;">未使用总数：</p>{{this.statistics.use_not}}</div>
    </div>

    <!-- 库存显示 -->
    <div style="width:100%;display:flex;flex-wrap:wrap;min-width:1050px">
      <el-tag style="margin-right:20px;margin-bottom:15px" v-for="(item,key,index) in domainStock" :key="index" type="info"><p style="display:inline-block;font-weight:bolder">{{key}}</p>:{{item}}</el-tag>
    </div>

    <!-- 表格 -->
    <el-table
      :height="tableHeight"
      :key="key"
      stripe
      v-loading="loading"
      element-loading-background="rgba(255,255,255,0.9)"
      ref="multipleTable"
      :data="ShowTableData"
      tooltip-effect="dark"
      style="width:calc(100%-60px);line-height:30px;margin:25px 0px;min-width:1025px;"
      border>
      <!-- <el-table-column type="selection" width="55"></el-table-column> -->
      <el-table-column prop="" label="详情" width="50px">
        <template slot-scope="scope">
          <el-button
            type="text" icon="el-icon-arrow-right"
            size="small"
            @click="tableOpen(scope.row)"
            style="padding-left: 9px;color:#909399"
          ></el-button>
        </template>
      </el-table-column>
      <el-table-column prop="domain_name" label="域名"></el-table-column>
      <el-table-column prop="zh_name" label="用户"></el-table-column>
      <el-table-column label="是否在使用">
        <template slot-scope="scope">
          <span v-if="scope.row.use_in === '0'">否</span>
          <span v-else>是</span>
        </template>
      </el-table-column>
      <el-table-column label="是否删除">
        <template slot-scope="scope">
          <span v-if="scope.row.delete === '0'">否</span>
          <span v-else>是</span>
        </template>
      </el-table-column>
      <el-table-column  label="是否出售">
        <template slot-scope="scope">
          <span v-if="scope.row.sell === '0'">否</span>
          <span v-else>是</span>
        </template>
      </el-table-column>
      <el-table-column prop="create_time_change" label="购买时间"></el-table-column>
      <el-table-column prop="expiring_time_change" label="到期时间"></el-table-column>
      <el-table-column fixed="right" label="操作" width="300px">
        <template slot-scope="scope">
          <el-button :disabled="scope.row.use_in === '1' ? true:false" type="text" size="small" @click="domainDistribution(scope.row)">域名分配</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="block" style="position: relative; right: 0px; margin-bottom: 80px;min-width:1025px;" v-if="!loading">
      <el-pagination :page-size="20" background @current-change="fetchPageData()" :current-page.sync="currentPage" layout="prev, pager, next" :total="totalNum" :disabled="loading">
      </el-pagination>
    </div>

    <!-- 详情抽屉 -->
    <el-drawer class="noselect" title="详情" :visible.sync="table" direction="rtl" size="600px">
      <el-form ref="makeOver_form" label-width="100px" label-position="left" style="padding-left:70px;min-height:500px" v-loading="loadingDetail">
        <el-form-item size="small" label="子域名: " class="noselect">
          <p style="text-align:left;text-decoration:underline;cursor: pointer;" v-for="item in detail_subDomain" :key="item" :label="item" :value="item"  v-clipboard:copy="item" v-clipboard:success="onCopy" v-clipboard:error="onError">{{item}}</p>
        </el-form-item>
      </el-form>
    </el-drawer>

    <!-- 域名分配 -->
    <el-dialog title="域名分配" :visible.sync="domainDistribution_dialogVisible" width="400px" :close-on-click-modal="false">
      <el-form label-width="100px" label-position="right" v-loading="distribution_loading">
        <el-row>
          <el-col :span="24">
            <el-form-item label="选择用户" class="noselect" style="margin-right: 40px">
              <el-select v-model="domainDistribution_dialog.uid" filterable placeholder="选择">
                <!-- <el-option   v-for="item in userList" :key="item.uid" :value="item.uid" :label="item.zh_name"> -->
                <el-option   v-for="(item,key,index) in userList" :key="index" :value="item.uid" :label="item.zh_name">
                  <span style="float: left">{{ item.zh_name}}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ item.uid }}</span> 
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-button @click="domainDistribution_submit" size="small" type="primary" class="formSubmitBtn" style="margin-right:-220px">确 定</el-button>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableHeight:530,
      distribution_loading:false,
      key: 0,
      //multipleSelectionFlag_delete: true, // 删除按钮出现与否
      multipleSelection_delete: "", // 批量选中项
      // 加载界面显示与否
      loading: true,
      loadingDetail:false,
      // 过滤后数据
      ShowTableData: [],
      // 原始数据
      tableData: [],
      //搜索记录
      searchParams: {
        accurateSearch: '',
      },
      // 详情抽屉
      table: false,
      // 分页
      totalNum: 10,
      currentPage: 1,
      useSearchData: false,
      //详情
      detail_subDomain: [],
      //域名库存
      domainStock:null,
      // 统计
      statistics: {},
      // 域名分配表单
      domainDistribution_dialogVisible:false,
      domainDistribution_dialog: {
        uid: null,
        domain_name:null,
      },
      // 用户列表
      userList:null
    };
  },

  created() {
    this.fetch();
  },

  methods: {
    async fetchPageData() {// 点击页码
      this.loading = true;
      if (this.useSearchData === false) {
        let formData = new FormData();
        formData.append("page", this.currentPage);
        formData.append("user",1000)
        await this.$http.post("/index.php/index/domain/domainStock/",formData).then((res) => {
          res.data["domain"].forEach(e=> {
            e["create_time_change"] = this.getLocalTime(parseInt(e["create_time"]));
            e["apply_time_change"] = this.getLocalTime(parseInt(e["apply_time"]));
            e["expiring_time_change"] = this.getLocalTime(parseInt(e["expiring_time"]));
          })
          this.ShowTableData = res.data["domain"]
          this.loading = false;
        });
      } else {
          this.ShowTableData = [];
          this.tableData.forEach((e) => {
            if (
              this.tableData.indexOf(e) <= (this.currentPage - 1) * 20 + 19 &&
              this.tableData.indexOf(e) >= (this.currentPage - 1) * 20
            ) {
              this.ShowTableData.push(e);
            }
          });
          this.loading = false;
        }
        this.getTableHeight()
    },
    async search() {// 搜索
      this.loading = true;
      this.useSearchData = true;
      this.currentPage = 1;
      let formData = new FormData();
      formData.append("domain",this.searchParams.accurateSearch)
      formData.append("user",1000)
      if (this.searchParams.accurateSearch === null || this.searchParams.accurateSearch === '') {
        this.useSearchData = false;
        this.fetch()
      } else {
          await this.$http.post("/index.php/index/domain/domainSearch/",formData).then((res) => {
          this.tableData = res.data["subDomain"]
          this.totalNum = res.data["subDomain"].length
          res.data["subDomain"].forEach(e=> {
            e["create_time_change"] = this.getLocalTime(parseInt(e["create_time"]));
            e["apply_time_change"] = this.getLocalTime(parseInt(e["apply_time"]));
            e["expiring_time_change"] = this.getLocalTime(parseInt(e["expiring_time"]));
          })
          this.ShowTableData =[]
          if (res.data["subDomain"].length <=20) {
            for (let i = 0; i < res.data["subDomain"].length; i++) {
              this.ShowTableData.push(res.data["subDomain"][i])
            }
          } else {
              for (let i = 0; i < 20; i++) {
                this.ShowTableData.push(res.data["subDomain"][i])
              }
          }
          this.loading = false;
        });
      }
      this.getTableHeight()
    },
    onCopy() {// 复制成功
      this.$message.success('复制成功')
    },
    onError() {// 复制失败
      this.$message.error('复制失败')
    },
    async tableOpen(e) {// 详情
      this.table = true;
      this.loadingDetail = true
      this.detail_subDomain = []
      let formData = new FormData();
      formData.append("domain", e.domain_name);
      formData.append("user", 1000);
      await this.$http.post("/index.php/index/domain/subDomain/",formData)
      .then((res) => {
        // this.detail_subDomain = res.data["subDomain"]
        res.data["subDomain"].forEach(e=> {
          this.detail_subDomain.push(`${`${e["top"]}`+ '.' +e["domain"]}`)
        })
        this.loadingDetail = false
      });
    },
    async fetch() {// 数据获取
      this.loading = true
      let formData = new FormData()
      formData.append("user",1000)
      await this.$http.post("/index.php/index/domain/domainStock/",formData).then((res) => {
        console.log('data!',res);
        this.userList = res.data["user"]
        //  for(var i=0;i<res.data["user"].length;i++) {
        //     this.userList[i] = res.data["user"][i];
        //   }
        this.domainStock = res.data["domain_count"]
        this.statistics = res.data["count"]
        this.totalNum = this.statistics["sum"]
        res.data["domain"].forEach(e=> {
          e["create_time_change"] = this.getLocalTime(parseInt(e["create_time"]));
          e["apply_time_change"] = this.getLocalTime(parseInt(e["apply_time"]));
          e["expiring_time_change"] = this.getLocalTime(parseInt(e["expiring_time"]));
        })
        this.ShowTableData = res.data["domain"]
        this.loading = false;
      });
      this.getTableHeight()
    },
    getLocalTime(nS) {// 时间戳转换
      let time = new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ').replace(/\//g, '-');
      // 找出出现空格的位置
      let space_position = time.indexOf(' ');
      // 截取并返回数据
      return time.slice(0,space_position);
    },
    domainDistribution(row) {// 域名分配表单
      this.domainDistribution_dialogVisible = true
      this.domainDistribution_dialog.domain_name = row.domain_name
    },
    async domainDistribution_submit() {// 域名分配表单提交
      this.distribution_loading = true
      let formData = new FormData() 
      formData.append("domain",this.domainDistribution_dialog.domain_name)
      formData.append("user",this.domainDistribution_dialog.uid)
      await this.$http.post('/index.php/index/domain/domainAllot/',formData).then((res) => {
        if (res.data["code"] === 200) {
          this.$message({
            type: "success",
            message: `${res.data["data"]}`,
          });
          this.fetchPageData()
        } else {
            this.$message({
              type: "error",
              message: `${res.data["data"]}`,
            });
        }
        this.domainDistribution_dialogVisible = false
        this.distribution_loading = false
      })
    },
    getTableHeight() {//获取高度
      if (this.ShowTableData.length >= 9) {
        this.tableHeight = 9*53 + 56
      }  else if (this.ShowTableData.length === 0) {
        this.tableHeight = 120
      } else {
        this.tableHeight = this.ShowTableData.length*53 + 56
      }
    }
  },
};
</script>

<style scoped>
.el-tag.el-tag--info {
  background-color: white!important;
}
.iftop {
  color: #409EFF;
}
.iftop_not {
  color: grey;
}
.el-dropdown-menu__item {
  text-align: center;
}
.is-active {
  background-color: white !important;
}
.el-select-dropdown__item.selected {
  /* color: rgb(65, 181, 132) !important; */
  font-weight: 700;
}
.el-main {
  line-height: 20px !important;
}
.el-button--primary {
  color: rgb(41, 42, 45) !important;
  background-color: #fff !important;
  border-color: rgb(41, 42, 45) !important;
}
.el-button--primary:hover {
  color: white !important;
  background-color: rgb(77, 77, 77) !important;
  border-color: rgb(77, 77, 77) !important;
}
.el-select {
  display: block !important;
}
</style>
