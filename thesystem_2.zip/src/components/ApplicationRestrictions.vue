<template>
  <div >
    <!-- 表格 -->
    <el-table
      :height="tableHeight"
      stripe
      v-loading="loading"
      element-loading-background="rgba(255,255,255,0.9)"
      ref="multipleTable"
      :data="ShowTableData"
      tooltip-effect="dark"
      style="width:calc(100%-60px);line-height:30px;margin:25px 0px 0px 0px;min-width:1035px;"
      border>
      <el-table-column prop="uid" label="ID"></el-table-column>
      <el-table-column prop="zh_name" label="用户"></el-table-column>
      <el-table-column prop="domain_today_limit" label="今日申请数量"></el-table-column>
      <el-table-column prop="domain_limit" label="总申请数量"></el-table-column>
      <el-table-column prop="site_today_limit" label="每天申请限制数"></el-table-column>
      <el-table-column prop="site_limit" label="总申请限制数"></el-table-column>
      <el-table-column fixed="right" label="操作" width="300px">
        <template slot-scope="scope">
          <el-button @click="changeLimit(scope.row)" type="text" size="small">修改限制</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="修改限制" :visible.sync="changeLimit_dialogVisible" width="400px" :close-on-click-modal="false">
      <el-form label-width="120px" label-position="right" v-loading="edit_loading">
        <el-row>
          <el-col :span="24">
            <el-form-item label="每日申请限制数" class="noselect" style="margin-right: 40px">
              <el-input-number style="width:220px;" v-model="changeLimit_submit_params.site_today_limit" :min="0" :max="20"></el-input-number>
            </el-form-item>
            <el-form-item label="总申请限制数" class="noselect" style="margin-right: 40px">
              <el-input-number style="width:220px;" v-model="changeLimit_submit_params.site_limit" :min="0" :max="100"></el-input-number>
            </el-form-item>
          </el-col>
        </el-row>
        <el-button @click="changeLimit_submit" size="small" type="primary" class="formSubmitBtn" style="margin-right:-220px">确 定</el-button>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableHeight:620,
      edit_loading:false,
      loading: true,
      // 过滤后数据
      ShowTableData: [],
      // 原始数据
      tableData: [],
      //表单
      changeLimit_dialogVisible:false,
      changeLimit_submit_params: {
        user:null,
        site_today_limit:null,
        site_limit:null
      }
    };
  },

  created() {
    this.fetch();
  },

  methods: {
    getTableHeight() {//获取高度
      if (this.ShowTableData.length >= 14) {
        this.tableHeight = 14*53 + 56
      }  else if (this.ShowTableData.length === 0) {
        this.tableHeight = 120
      } else {
        this.tableHeight = this.ShowTableData.length*53 + 56
      }
    },
    async fetch() {// 数据获取
      this.loading = true
      let formData = new FormData()
      formData.append("user",1000)
      await this.$http.get("/index.php/index/domain/userList/",formData).then((res) => {
        console.log('data!',res);
        this.ShowTableData = res.data
        this.loading = false;
      });
      this.getTableHeight()
    },
    changeLimit(e) {
      this.changeLimit_submit_params.user = e.uid
      this.changeLimit_submit_params.site_today_limit = e.site_today_limit
      this.changeLimit_submit_params.site_limit = e.site_limit
      this.changeLimit_dialogVisible = true
    },
    async changeLimit_submit() {
      this.edit_loading = true
      let formData = new FormData()
      formData.append('user',this.changeLimit_submit_params.user)
      formData.append('site_today_limit',this.changeLimit_submit_params.site_today_limit)
      formData.append('site_limit',this.changeLimit_submit_params.site_limit)
      console.log(this.changeLimit_submit_params);
      await this.$http.post('/index.php/index/domain/changelimit/',formData).then((res)=> {
        console.log(res);
        if (res.data > 0) {
          this.$message({
            type: "success",
            message: "修改成功",
          });
          this.fetch()
          this.changeLimit_dialogVisible = false
        } else {
            this.$message({
              type: "error",
              message: "修改失败",
          });
        }
        this.edit_loading = false
      })
    }
  },
};
</script>

<style scoped>
.el-tag.el-tag--info {
  background-color: white!important;
}
.iftop {
  color: #409EFF;
}
.iftop_not {
  color: grey;
}
.el-dropdown-menu__item {
  text-align: center;
}
.el-button--info {
  background-color: white !important;
  color: #606266 !important;
}
.is-active {
  background-color: white !important;
}
.el-select-dropdown__item.selected {
  /* color: rgb(65, 181, 132) !important; */
  font-weight: 700;
}
.el-main {
  line-height: 20px !important;
}
.el-button--primary {
  color: rgb(41, 42, 45) !important;
  background-color: #fff !important;
  border-color: rgb(41, 42, 45) !important;
}

.el-button--primary:hover {
  color: white !important;
  background-color: rgb(77, 77, 77) !important;
  border-color: rgb(77, 77, 77) !important;
}
.el-select {
  display: block !important;
}
</style>
