<template>
  <div>
    <!-- 搜索框 -->
    <div style="display: flex;position:relative;min-width:915px">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display: flex; flex-wrap: wrap;" :disabled="loading">
        <el-form-item class="noselect" style="margin-right: 30px">
          <div style="text-align: left; margin-bottom: 5px">账户名称</div>
          <el-input v-model="searchParams.remark" placeholder="搜索账户名称" clearable style="width: 120px;"></el-input>
        </el-form-item>
        <el-form-item  class="noselect" style="margin-right:30px">
          <div style="text-align: left; margin-bottom: 5px">账号</div>
          <el-input v-model="searchParams.remark" placeholder="搜索账号" clearable style="width: 120px;"></el-input>
        </el-form-item>
        <el-form-item  class="noselect" style="margin-right:30px">
          <div style="text-align: left; margin-bottom: 5px">广告账号ID</div>
          <el-input v-model="searchParams.remark" placeholder="搜索ID" clearable style="width: 120px;"></el-input>
        </el-form-item>
        <el-form-item  class="noselect" style="margin-right:30px">
          <div style="text-align: left; margin-bottom: 5px">信用卡号</div>
          <el-input v-model="searchParams.remark" placeholder="搜索信用卡号" clearable style="width: 120px;"></el-input>
        </el-form-item>
        <el-form-item class="noselect" style="margin-right: 30px">
          <div style="text-align: left; margin-bottom: 5px">充值卡号</div>
          <el-input v-model="searchParams.remark" placeholder="搜索充值卡号" clearable style="width: 120px;"></el-input>
        </el-form-item>
        <el-form-item  class="noselect" style="margin-right:30px">
          <div style="text-align: left; margin-bottom: 5px">BM</div>
          <el-input v-model="searchParams.remark" placeholder="搜索BM" clearable style="width: 120px;"></el-input>
        </el-form-item>
        <el-form-item class="noselect" style="margin-right: 30px">
          <div style="text-align: left; margin-bottom: 5px">备注</div>
          <el-input v-model="searchParams.remark" placeholder="搜索备注" clearable style="width: 150px;"></el-input>
        </el-form-item>
        <el-form-item class="noselect">
          <el-button icon="el-icon-search" @click="search" plain style="height: 30px; position: relative; margin-top: 32px">搜索</el-button>
        </el-form-item>
        <el-form-item class="noselect">
          <el-button class="info_btn" icon="el-icon-upload2" @click="import_form_dialogVisible = true" type="info" style="height: 30px; position: relative; margin-top: 32px;margin-left:10px;">导入</el-button>
          <el-button class="info_btn" icon="el-icon-download" @click="export_form_dialogVisible = true" type="info" style="height: 30px; position: relative;right:-10px; margin-top: 32px;margin-left:10px;" >导出选中项</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 表格 -->


    <!-- 表格 -->
    <el-table
      :height="tableHeight"
      :key="key"
      stripe
      v-loading="loading"
      element-loading-background="rgba(255,255,255,0.9)"
      ref="multipleTable"
      :data="ShowTableData"
      tooltip-effect="dark"
      style="width:calc(100%-60px);line-height:30px;margin:25px 0px;min-width:800px"
      :row-style="{height: '50px'}"
      border
      @selection-change="handleSelectionChange_delete">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="" label="详情" width="50px">
          <template slot-scope="scope">
            <el-button
              type="text" icon="el-icon-arrow-right"
              size="small"
              @click="tableOpen(scope.row)"
              style="color:#909399;padding:0 0 0 9px!important"
              ></el-button>
          </template>
      </el-table-column>
      <el-table-column prop="_id" label="系统ID" width="100px">
      </el-table-column>
      <el-table-column prop="account" label="账号" width="300px">
      </el-table-column>
      <el-table-column prop="type" label="类型" width="100px">
      </el-table-column>
      <el-table-column prop="accountname" label="账户名称" width="320px">
      </el-table-column>
      <el-table-column prop="limit" label="限额" width="50px">
      </el-table-column>
      <el-table-column prop="comebatch" label="来号批次" width="100px">
      </el-table-column>
      <el-table-column prop="extension" label="推广" width="160px">
      </el-table-column>
      <el-table-column prop="remarks" label="备注">
      </el-table-column>
      <el-table-column prop="status" label="状态" width="100px">
      </el-table-column>
      <el-table-column fixed="right" label="操作" align="center" width="130px">
        <template slot-scope="scope">
          <el-dropdown placement="bottom" trigger="click">
            <span style="cursor: pointer;" class="el-dropdown-link">
              <i style="color: grey!important" class="el-icon-more"></i>
            </span>
            <el-dropdown-menu class="noselect" slot="dropdown">
              <el-dropdown-item @click.native="edit_form_open(scope.row)">编辑账号</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>


    <!-- 分页 -->
    <div class="block" style="position: relative; right: 0px; margin-bottom: 25px" v-if="!loading">
      <!-- <el-pagination
        :page-size="10"
        background
        @current-change="fetchPageData()"
        :current-page.sync="currentPage"
        layout="prev, pager, next"
        :total="totalNum"
        :disabled="loading"
      >
      </el-pagination> -->
          <el-pagination
    background
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page.sync="currentPage2"
      :page-sizes="[100, 200, 300, 400]"
      :page-size="100"
      layout="sizes, prev, pager, next"
      :total="1000">
    </el-pagination>
    </div>
    

    <!-- 详情抽屉 -->
    <el-drawer class="noselect" title="详情" :visible.sync="table" direction="rtl" size="600px">
      <el-form ref="makeOver_form"  label-width="100px" label-position="left"  style="padding-left:70px">
        <el-form-item size="small" label="账号：" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_account" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_account}}</p>
        </el-form-item>
        <el-form-item size="small" label="密码：" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_password" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_password}}</p>
        </el-form-item>
        <el-form-item size="small" label="cookie：" class="noselect" style="position: relative">
          <el-button type="text" icon="el-icon-arrow-left"
              size="small" @click="innerDrawer = true" style="position: absolute;left:0;color:black"></el-button>
        </el-form-item>
        <el-form-item size="small" label="账号BM：" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_accountbm" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_accountbm}}</p>
        </el-form-item>
        <el-form-item size="small" label="账户名称" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_accountname" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_accountname}}</p>
        </el-form-item>
        <el-form-item size="small" label="广告账号ID：" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_adid" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_adid}}</p>
        </el-form-item>
        <el-form-item size="small" label="信用卡号：" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_cardNumber" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_cardNumber}}</p>
        </el-form-item>
        <el-form-item size="small" label="充值卡号：" class="noselect">
          <p style="text-align:left;text-decoration:underline" v-clipboard:copy="this.detail_rechargeCardNumber" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_rechargeCardNumber}}</p>
        </el-form-item>
        <el-form-item size="small" label="来号日期：" class="noselect">
          <p style="text-align:left">{{this.detail_ComeDate}}</p>
        </el-form-item>
        <el-form-item size="small" label="登陆IP：" class="noselect">
          <p style="text-align:left">{{this.detail_ip}}</p>
        </el-form-item>
        <el-form-item size="small" label="上传时间：" class="noselect">
          <p style="text-align:left">{{this.detail_uploaddate}}</p>
        </el-form-item>
        <el-form-item size="small" label="更新时间：" class="noselect">
          <p style="text-align:left">{{this.detail_updatedate}}</p>
        </el-form-item>
        <el-form-item size="small" label="日志记录：" class="noselect">
          <p style="text-align:left;color:red">{{this.detail_Logging}}</p>
        </el-form-item>
      </el-form>
      <!-- 嵌套抽屉 -->
      <div>
        <el-drawer
          title="cookie"
          :append-to-body="true"
          :visible.sync="innerDrawer"
          class="noselect"
          size="500px">
          <div style="word-wrap:break-word;padding: 0 20px 0 20px;text-decoration:underline;line-height: 20px;" v-clipboard:copy="this.detail_cookie" v-clipboard:success="onCopy" v-clipboard:error="onError">{{this.detail_cookie}}</div>
        </el-drawer>
      </div>
    </el-drawer>

    <!-- 编辑表单 -->
    <el-dialog title="编辑" :visible.sync="edit_form_dialogVisible" width="800px">
      <el-form  :rules="rules" ref="edit_form" :model="edit_form" label-width="100px" label-position="right">
        <el-row>
          <el-col :span="12">
            <el-form-item  label="账号类型" class="noselect" style="margin-right:40px" prop="accountType">
              <el-select v-model="edit_form.accountType" placeholder="筛选" clearable>
                <el-option v-for="item in chooseType" :key="item" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="密码" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.password" clearable>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item  label="登陆地区" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.ip" placeholder="筛选" clearable>
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="账户名称" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.accountName"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item  label="限额" class="noselect" style="margin-right:40px">
              <el-select v-model="edit_form.limit" placeholder="筛选" clearable>
                <el-option v-for="item in chooseLimit" :key="item" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="广告账号ID" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.adid"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item  label="BM" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.bm"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="充值卡号" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.rechargeCardNumber"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item  label="信用卡号" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.cardNumber"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="来号日期" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.comeDate"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item  label="来号批次" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.comeBatch"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="备注" class="noselect" style="margin-right:40px">
              <el-input v-model="edit_form.remarks"  style="position: absolute;left: 0"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item  label="状态" class="noselect" style="margin-right:40px" prop="status">
              <el-select v-model="edit_form.status" placeholder="筛选" clearable>
                <el-option v-for="item in chooseStatus" :key="item" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item  label="cookie" class="noselect" style="margin-right:40px" prop="cookie">
              <el-input type="textarea" v-model="edit_form.cookie"  clearable>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-button size="small" type="primary" @click="submitForm('edit_form')" class="formSubmitBtn" style="margin-right: 500px;">确 定</el-button>
      </el-form>
    </el-dialog>

    <!-- 导出表单 -->
    <el-dialog :visible.sync="export_form_dialogVisible" width="500px">
      <el-form ref="export_form" :model="export_form" label-width="100px" label-position="right">
        <el-form-item label="请选择时间段" label-width="100px" style="position:relative">
          <el-date-picker
          v-model="export_form.selected"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期">
        </el-date-picker>
        </el-form-item>
        <el-button size="small" type="primary" @click="submitForm('export_form')" class="formSubmitBtn" style="margin-right: 390px;">确 定</el-button>
      </el-form>

    </el-dialog>

    <!-- 导入表单 -->
    <el-dialog :visible.sync="import_form_dialogVisible" width="500px" >
      <el-upload drag
        v-loading="loading_import"
        style="margin-bottom: 25px;"
        :limit=limitNum
        :auto-upload="false" 
        accept=".xlsx"
        :action="UploadUrl()"
        :before-upload="beforeUploadFile"
        :on-change="fileChange"
        :on-exceed="exceedFile"
        :on-remove="handleRemove"
        :file-list="fileList">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或<em style="color: #409EFF;">点击上传</em></div>
        <div class="el-upload__tip" slot="tip">只能上传xlsx文件，且不超过10M</div>
      </el-upload>
      <el-button :disabled="loading_import" size="small" type="primary" @click="uploadFile">立即上传</el-button>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        tableHeight:620,
        loading_import:false,
        key:0,
        import_form_dialogVisible: false,//导入表单显示
        limitNum: 1,  // 上传excell时，同时允许上传的最大数
        fileList: [],   // excel文件列表
        // 导出表单
        export_form_dialogVisible: false,
        export_form: {
          selected: null
        },
        //编辑表单
        edit_form: {
          accountType: null,
          password: null,
          ip:null,
          accountName: null,
          limit: null,
          adid: null,
          bm: null,
          cardNumber: null,
          rechargeCardNumber: null,
          comeDate: null,
          comeBatch: null,
          status: null,
          cookie: null,
          remarks: null
        },
        // 编辑表单的显示
        edit_form_dialogVisible: false,
        //停用表单的数据
        deactivate_form: {
          deactivate_id : null,
          deactivate_accountname: null,
        },
        // 详情抽屉
        detail_account:null,// 临时数据 懒得造
        detail_password:null,
        detail_cookie:null,
        detail_accountbm:null,
        detail_accountname:null,
        detail_adid: null,
        detail_cardNumber:null,
        detail_rechargeCardNumber: null,
        detail_ComeDate:null,
        detail_ip:null,
        detail_uploaddate:null,
        detail_updatedate: null,
        detail_Logging:null,
        table: false,
        innerDrawer: false,
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载界面显示与否
        loading: false,
        // 展示数据
        ShowTableData: [],
        ShowTableData_Highquota: null,
        // 原始数据
        tableData: null,
        // 搜索账号类型选项
        chooseType: null,
        chooseLimit: null,
        chooseStatus:null,
        chooseExtension: null,
        // 搜索输入框记录
        searchParams: {
          remark:null
        },
        //校验规则
        rules: {
          // 申请账号校验规则
          accountType: [
            { required: true, message: '请选择账户类型', trigger: 'change' }
          ],
          status: [
            { required: true, message: '请选择状态', trigger: 'change' }
          ],
          cookie: [
            { required: true, message: '请输入cookie', trigger: 'blur' }
          ],
        },
        uid:null,
      // 分页
      totalNum: 10,
      currentPage: 1,
      useSearchData: false,
      }
    },

    created() {
      // 执行网络请求
      this.fetchOption()
      //获取表单选项及表格数据
      this.fetch()
      this.getUid()
    },

    methods: {
      // 分页
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      },
      // //////////
    getTableHeight() {
      if (this.ShowTableData.length >= 12) {
        this.tableHeight = 12*50 + 56
      } else if (this.ShowTableData.length === 0) {
        this.tableHeight = 120
      }  else {
        this.tableHeight = this.ShowTableData.length*50 + 56
      }
    },
    async fetchPageData() {// 点击页码
      // this.loading = true;
      // if (this.useSearchData === false) {
      //   let formData = new FormData();
      //   formData.append("page", this.currentPage);
      //   formData.append("user",this.uid)
      //   await this.$http.post("/index.php/index/ad/adPage/",formData)
      //     .then((res) => {
      //       res.data.forEach((e) => {
      //         e["create_time_change"] = utils.getLocalTime(
      //           parseInt(e["create_time"])
      //         );
      //         e["click_visit"] =  e["now_visit"] + " / " + e["now_click"];
      //         e["qualified_domain_name"] = e["top"] + "." + e["domain"];
      //         if (typeof e["country_zh"] === 'string') {
      //           //
      //         } else {
      //           e["country_zh"] = e["country_zh"].join()
      //         }
      //       });
      //       this.ShowTableData = [];
      //       this.tableData = res.data;
      //       this.tableData.forEach((e) => {
      //         if (this.tableData.indexOf(e) <= 9) {
      //           this.ShowTableData.push(e);
      //         }
      //       });
      //       this.loading = false;
      //       this.handleUpdateClick()
      //     });
      // } else {
      //     this.ShowTableData = [];
      //     this.tableData.forEach((e) => {
      //       if (
      //         this.tableData.indexOf(e) <= (this.currentPage - 1) * 10 + 9 &&
      //         this.tableData.indexOf(e) >= (this.currentPage - 1) * 10
      //       ) {
      //         this.ShowTableData.push(e);
      //       }
      //     });
      //     this.loading = false;
      //     this.handleUpdateClick()
      //   }
    },
    async fetch() {// 数据获取
      // this.loading = true
      // let formData = new FormData()
      // formData.append("num",1)
      // await this.$http.post("/index.php/index/Services/servicesList/",formData).then((res) => {
      //   this.tableData = res.data["data"];
      //   this.ShowTableData = this.tableData;
        this.getTableHeight()
      //   this.loading = false;
      //   this.getTableHeight()
      // });
    },
    handleSelectionChange_delete(val) {// 批量选中
      // console.log(val);
      this.multipleSelection_delete = val;
      this.multipleSelectionFlag_delete = false;
      if (this.multipleSelection_delete.length == 0) {
        // 如不进行判断则勾选完毕后批量删除按钮还是会在
        this.multipleSelectionFlag_delete = true;
      }
    },
      getUid() { // 获取用户uid
        this.uid = localStorage.getItem("uid")
      },
      handleRemove() {
        this.fileList = []
      },
      exceedFile(files, fileList) {// 文件超出个数限制时的钩子
        this.$message.warning(`只能选择 ${this.limitNum} 个文件，当前共选择了 ${fileList.length} 个`);
      },
      fileChange(file, fileList) {// 文件状态改变时的钩子
        this.fileList.push(file.raw) ;
      },
      beforeUploadFile(file) {// 上传文件之前的钩子
        let extension = file.name.substring(file.name.lastIndexOf('.')+1);
        let size = file.size / 1024 / 1024;
        if(extension !== 'xlsx') {
          this.$message.warning('只能上传后缀是.xlsx的文件');
        }
        if(size > 10) {
          this.$message.warning('文件大小不得超过10M');
        }
      },
      UploadUrl:function(){
        return "#"
      },
      uploadFile() {
        if (this.fileList.length === 0){
          this.$message.warning('请上传文件');
        } else {
          this.loading_import = true
          let formData = new FormData();
          formData.append('file', this.fileList[0]);
          formData.append('user',this.uid)
          this.$http.post('/index.php/index/account/dataImport/',formData,{ headers: { "Content-Type": "multipart/form-data" } }).then((res) =>{
            this.loading_import = true
            console.log(res);
            if (res.data["code"] === 200) {
              this.$message.success(`${res.data["data"]}`)
              this.import_form_dialogVisible = false
            } else {
              this.$message.success(`${res.data["data"]}`)
            }
          })
        }
      },
      // -----------------------------------------------------------
      // 编辑表单数据
      edit_form_open(e) {
          this.edit_form.id = e._id
          this.edit_form.accountType = e.type
          this.edit_form.password = e.password
          this.edit_form.ip = e.ip
          this.edit_form.accountName = e.accountname
          this.edit_form.limit = e.limit
          this.edit_form.adid = e.adid
          this.edit_form.bm = e.accountbm
          this.edit_form.cardNumber = e.cardNumber
          this.edit_form.rechargeCardNumber = e.rechargeCardNumber
          this.edit_form.comeDate = e.ComeDate
          this.edit_form.comeBatch = e.comebatch
          this.edit_form.status = e.status
          this.edit_form.cookie = e.cookie
          this.edit_form.remarks = e.remarks
          this.edit_form_dialogVisible = true
      },
      // -----------------------------------------------------------
      //复制
      onCopy(e){
        this.$message({
          message:'复制成功！',
          type:'success'
        })
      },
      
      onError(e){
        this.$message({
          message:'复制失败！',
          type:'error'
        })
      },
      // -----------------------------------------------------------
      //表单提交
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
        });
      },
      //-------------------------------------------------------------
      // 转让
      makeOver_btn(e) {//点击转让按钮
        this.makeOver_form.makeOver_accountname = e.accountName
        this.makeOver_form.makeOver_id = e._id
        this.makeOver_form.makeOver_quota = e.limit
        this.makeOver_form_dialogVisible = true
      },
      //--------------------------------------------------------------
      // 详情
      tableOpen(e) {
        console.log(e);
        this.table = true
        this.detail_account = e.account
        this.detail_password = e.password
        this.detail_cookie = e.cookie
        this.detail_accountbm = e.accountbm
        this.detail_accountname = e.accountname,
        this.detail_adid = e.adid,
        this.detail_cardNumber = e.cardNumber,
        this.detail_rechargeCardNumber = e.rechargeCardNumber,
        this.detail_ComeDate = e.ComeDate,
        this.detail_ip = e.ip,
        this.detail_uploaddate = e.uploaddate,
        this.detail_updatedate = e.updatedate,
        this.detail_Logging = e.Logging
      },
      //--------------------------------------------------------------
      // 搜索选项获取
      fetchOption() {
        // this.$http.get('/accounttable.json').then((res) => {// 获取数据
          // this.tableData = res.data.RecyclingApproval//保留原数据
          // this.ShowTableData = this.tableData//原数据赋值给展示的表格数据
          //根据数据填充下拉选项-账号类型
          // this.chooseType = res.data.accountTypeFilter
          // this.chooseLimit = res.data.limitFilter
          // this.chooseStatus = res.data.statusFilter
          // this.chooseExtension = res.data.extensionFilter
          //数据完成展示后取消加载页面
          this.loading = false
        // })
      },
      //--------------------------------------------------------------
      //搜索提交
      search() {
        console.log(this.searchParams);
      },
      fetchData() {
        // this.$http.get('/accounttable.json').then((res) => {// 获取数据
        //   this.ShowTableData = res.data.accounttabledata//保留原数据
        //   //数据完成展示后取消加载页面
        //   this.loading = false
        // })
      }
    },
  }
</script>

<style scoped>
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
  color: rgb(41, 42, 45) !important;
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
.el-button--primary {
  color: rgb(41, 42, 45) !important;
  background-color: #fff !important;
  border-color: rgb(41, 42, 45) !important;
}
.el-button--primary:hover {
  color: white !important;
  background-color: rgb(77, 77, 77) !important;
  border-color: rgb(77, 77, 77) !important;
}

  .el-select {
    display: block!important;
  }
  .info_btn {
  background-color: #353639!important;
  color: white!important;
  border-color: #353639!important;
}
.info_btn:hover {
  background-color: #4D4D4D!important;
  border-color: #4D4D4D!important;
}
.el-button--primary.is-disabled {
  border-color: #C0C4CC!important;
  color:#C0C4CC!important;
  background-color: white!important;
}
.el-button--info.is-disabled {
  border-color: #C0C4CC!important;
  color:#C0C4CC!important;
  background-color: white!important;
}

.el-button--primary.is-disabled:hover {
  color: #C0C4CC!important;
}
</style>
