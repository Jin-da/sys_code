<template>
  <div style="position:relative;">
    <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap;position:absolute;left:30px;z-index:2">
        <el-form-item label="推广" class="noselect">
          <el-select :disabled='serach_disabled' v-model="accountstatistics_form.member" placeholder="筛选" clearable style="width:200px">
            <el-option v-for="item in options_Member" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-date-picker
          :disabled='serach_disabled'
          :clearable='false'
          :editable='false'
            v-model="accountstatistics_form.date"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button :disabled='serach_disabled' @click="onSubmit" type="primary" icon="el-icon-search" style="height: 30px;background-color: rgb(65, 181, 132) !important;color:white!important;border-color: white!important "></el-button>
        </el-form-item>
        <el-form-item>
          <el-button v-show="showIf_loading" type="text" size="medium" icon="el-icon-loading" style="font-size:20px;color:grey;padding-top:3px">
          </el-button>
        </el-form-item>
    </el-form>
    <div v-show="showIf" style="top:60px;margin-bottom:50px" id="myChart" :style="{ width:'100%', height: '500px' }"></div>
    <div v-show="showif_all" id="allChart" :style="{ width:'100%',height: '800px' }"></div>
  </div>
</template>

<script>
// 引入基本模板
let echarts = require("echarts/lib/echarts");
export default {
  
  name: "hello",
  data() {
    return {
      showif_all: false,
      serach_disabled: false,
      showIf_loading:false,
      showIf: false,
      echarts_personal_data_nolimit: [],
      echarts_personal_data_limit25:[],
      echarts_personal_data_limit50: [],
      echarts_personal_data_somelimit: [],
      accountstatistics_form: {
        member: '',
        date: ''
      },
      //选项
      //echarts个人数据
      echarts_data: {
        type: ["限25", "限50", "半限", "不限"],
        x_data: [
              "大黑号",
              "冷黑号",
              "耐用号",
              "专业号",
              "BM号",
              "信用卡",
              "泰铢",
              "印尼盾",
              "欧元",
              "邮箱",
              "秘鲁号",
              "支付宝",
              "越南号",
              "马币",
              "信用卡泰铢",
              "信用卡欧元"
        ]
      },
      options_Member: [
        "翁锡鹏",
        "李炼蕊",
        "陈焜先",
        "曾林",
        "杨晓海",
        "陈清秀",
        "邱晓辉",
        "麦小龙",
        "陈伟明",
        "许奕坤",
        "龚瑞琪",
        "徐五娇",
        "彭才蝶",
        "李广鑫",
        "李越",
        "林启隆",
        "黄晨娃",
        "陈少坤",
        "王一凯",
        "黎宇浩",
        "冯慧杰",
        "梁艺镪",
        "黄业柏",
        "蔡创艺",
        "柯绍福",
        "吴梓立",
        "柯庆朗"
      ]
    };
  },
  created() {
    this.accountstatistics_form.date = this.getNowFormatDate()
    this.onSubmit() 
  },
  methods: {
    //获取当前日期，格式YYYY-MM-DD
    getNowFormatDate() {
      var date = new Date();
      var seperator1 = "-";
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var strDate = date.getDate();
      if (month >= 1 && month <= 9) {
          month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
      }
      var currentdate = year + seperator1 + month + seperator1 + strDate;
      return currentdate;
    },
    //--------------------------------------------------------------
    //搜索提交
    onSubmit() {
      // console.log(this.accountstatistics_form);
      this.showif_all = false,
      this.showIf = false,
      this.showIf_loading = true
      this.serach_disabled = true
      setTimeout(()=> {
        this.fetchData()
      },1000)
    },
    //数据获取
    fetchData() {
      this.$http.get('/accountstatistics.json').then((res) => {// 获取数据
        this.echarts_personal_data_nolimit = res.data.echarts_personal_data_nolimit
        this.echarts_personal_data_limit25 = res.data.echarts_personal_data_limit25
        this.echarts_personal_data_limit50 = res.data.echarts_personal_data_limit50
        this.echarts_personal_data_somelimit = res.data.echarts_personal_data_somelimit
        //数据完成展示后取消加载页面
      }).then(() => {
        if (this.accountstatistics_form.member != '') {
          try {
            echarts.dispose(document.getElementById('myChart'))//销毁前一个echarts
            echarts.dispose(document.getElementById('allChart'))//销毁前一个echarts
            this.showIf = true
            this.showif_all = true,
            // 计时器用来避免宽度塌陷
            setTimeout(()=>{
            //加载echarts的代码
              this.drawLine();
              this.drawLine_all();
            },1)
            this.showIf_loading = false
            this.serach_disabled = false
          } catch(e) {
              //
          }
        } else {
          try {
            this.showif_all = true
            this.showIf = false
            this.showIf_loading = false
            this.serach_disabled = false
            echarts.dispose(document.getElementById('allChart'))//销毁前一个echarts
            setTimeout(()=>{
            //加载echarts的代码
              this.drawLine_all();
            },1)
          } catch(e) {
              //
          }
        }
      })
    },
    //--------------------------------------------------------------
    //echarts-个人
    drawLine() {
      // 基于准备好的dom，初始化echarts实例
      let myChart = echarts.init(document.getElementById("myChart"));
      // window.addEventListener('resize',() => myChart.resize(),false);
      // 绘制图表
      myChart.setOption({
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow", // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        title: {
          text: this.accountstatistics_form.member + '-'+ this.accountstatistics_form.date + '-' + '个人统计',
          left: 30,
          top: 0,
          textStyle: {
            color: 'rgb(70,70,70)',
            fontSize:17
          }
        },
        legend: {
          data: this.echarts_data.type,
        },
        grid: {
          left: "5%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: this.echarts_data.x_data,
            axisLabel : {//坐标轴刻度标签的相关设置。
                interval:0,
                rotate:"45",
                fontSize: 15,
            }
          },
          
        ],
        yAxis: [
          {
            axisLabel : {//坐标轴刻度标签的相关设置。
                fontSize: 15
            },
            type: "value",
          },
        ],
        series: [
          // 各类型数据
          {
            name: "不限",
            type: "bar",
            stack: "广告",
            emphasis: {
              focus: "series",
            },
            data: this.echarts_personal_data_nolimit,
            itemStyle: {
              color: "rgb(20,163,143)"
            },
          },
          {
            name: "限25",
            type: "bar",
            stack: "广告",
            emphasis: {
              focus: "series",
            },
            data: this.echarts_personal_data_limit25,
            itemStyle: {
              color: "rgb(239,84,36)"
            },
          },
          {
            name: "限50",
            type: "bar",
            stack: "广告",
            emphasis: {
              focus: "series",
            },
            data: this.echarts_personal_data_limit50,
            itemStyle: {
              color: "rgb(56,86,106)"
            },
          },
          {
            name: "半限",
            type: "bar",
            stack: "广告",
            emphasis: {
              focus: "series",
            },
            data: this.echarts_personal_data_somelimit,
            itemStyle: {
              color: "rgb(247,164,64)"
            },
          }
        ],
      });
    },
    //--------------------------------------------------------------
    //echarts-全体
    drawLine_all() {
      // 基于准备好的dom，初始化echarts实例 
      let allChart = echarts.init(document.getElementById("allChart"));
      // window.addEventListener('resize',() => allChart.resize(),false);
      // 绘制图表
      allChart.setOption({
        backgroundColor: 'rgba(255,255,255,0)',
      title: {
        text: this.accountstatistics_form.date + '-' + '成员总计',
        left: 30,
        top: 60,
        textStyle: {
          color: 'rgb(70,70,70)',
          fontSize:17
        }
      },
      tooltip: {
          trigger: 'item'
      },

      visualMap: {
          show: false,
          min: 1,
          max: 50,
          inRange: {
              colorLightness: [0, 0.6]
          }
      },
      series: [
          {
              name: '总计',
              type: 'pie',
              radius: [50, 300],
              center: ['50%', '50%'],
              data: [
                  {value: 5, name: '翁锡鹏'},
                  {value: 10, name: '李炼蕊'},
                  {value: 20, name: '陈焜先'},
                  {value: 15, name: '曾林'},
                  {value: 5, name: '杨晓海'},
                  {value: 30, name: '陈清秀'},
                  {value: 25, name: '邱晓辉'},
                  {value: 10, name: '麦小龙'},
                  {value: 15, name: '陈伟明'},
                  {value: 5, name: '许奕坤'},
                  {value: 15, name: '龚瑞琪'},
                  {value: 20, name: '徐五娇'},
                  {value: 30, name: '彭才蝶'},
                  {value: 5, name: '李广鑫'},
                  {value: 15, name: '李越'},
                  {value: 25, name: '林启隆'},
                  {value: 10, name: '黄晨娃'},
                  {value: 35, name: '陈少坤'},
                  {value: 25, name: '王一凯'},
                  {value: 15, name: '黎宇浩'}
              ].sort(function (a, b) { return a.value - b.value; }),
              roseType: 'radius',
              label: {
                  color: 'rgb(70,70,70)'//rgba(255, 255, 255, 0.3)//标签颜色
              },
              labelLine: {
                  lineStyle: {
                      color: 'rgba(0, 0, 0, 0.2)'//指示线
                  },
                  smooth: 0.2,
                  length: 10,
                  length2: 20
              },
              itemStyle: {
                borderRadius: 8,
                  color: 'rgba(65,181,132,0.9)',
                  // shadowBlur: 200,
                  // shadowColor: 'rgba(0, 0, 0, 0.5)'
              },

              animationType: 'scale',
              animationEasing: 'elasticOut',
              animationDelay: function (idx) {
                  return Math.random() * 200;
              }
          }]
        });
    },
  },
  // 无法防止echarts获取不到当前页面节点而报错的情况，此处用于确保流程跑得通
  beforeRouteEnter(to,from ,next) {
    next((vm => {
      vm.onSubmit()
    }))
  },
//   beforeDestroy () {
//   window.onresize = null
// }
};
</script>

<style scoped>
.el-date-table>td.current:not(.disabled)>span {
    color: #FFF;
    background-color: red;
}
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
      color: rgb(65, 181, 132) !important;
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
  .el-button--primary {
      color: rgb(65, 181, 132) !important;
      background-color: #fff !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(65, 181, 132) !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--info {
      color: #606266 !important;
      background-color: #fff !important;
      border-color: rgb(220, 223, 230) !important;
  }
  .el-button--info:hover {
    box-shadow: rgb(0 21 41 / 8%) 2px 2px 4px;
  }
  .el-select {
    display: block!important;
  }
</style>