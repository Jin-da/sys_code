<template>
  <div style="min-width:1000px">
    <!-- 搜索框 -->
    <div style="display: flex;position:relative;margin-left: 30px;min-width: 1000px;">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap" :disabled="loading">
        <el-form-item v-if="buttonAuthority.searchObjectAuthority" class="noselect" style="margin-right:30px">
          <div style="text-align:left;margin-bottom:5px">落地页类别</div>
          <el-select v-model="searchParams.searchObject" placeholder="筛选" clearable style="width:150px">
            <el-option v-for="item in chooseDepartment" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item class="noselect" style="margin-top:32px;margin-bottom:5px">
          <el-input v-model="searchParams.accurateSearch" placeholder="搜索落地页名称" clearable style="width:200px">
          </el-input>
        </el-form-item>
        <!-- <el-form-item class="noselect">
          <el-button type="primary" icon="el-icon-plus" style="height: 30px" @click="new_form_dialogVisible=true">新建员工</el-button>
        </el-form-item> -->
        <el-form-item class="noselect">
          <el-button @click="search" type="info" style="height: 30px;position:relative;margin-top:32px">搜索</el-button>
          <!-- <div style="width:1px;height:40px;background-color:rgba(187, 187, 187, 0.5);position:absolute;bottom: -4px;left:85px;"></div>
          <div style="color:#00AEFF;font-size:12px;position:absolute;top:-12px;left:110px;width:60px;cursor:pointer">创建广告</div>
          <div style="color:#00AEFF;font-size:12px;position:absolute;top:12px;left:110px;width:60px;cursor:pointer">批量删除</div> -->
        </el-form-item>
      </el-form>
    </div>

    <!-- 表格 -->
    <el-table stripe v-loading="loading"  element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 25px" border @selection-change="handleSelectionChange_delete">
      <el-table-column type="selection" width="55">
      </el-table-column>
      <!-- <el-table-column prop="" label="详情" width="50px">
          <template slot-scope="scope">
            <el-button
              type="text" icon="el-icon-arrow-right"
              size="small"
              @click="tableOpen(scope.row)"
              style="padding-left: 9px;color:#909399"
              ></el-button>
          </template>
      </el-table-column> -->
      <!-- <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
          <span>{{(pageIndex - 1) * pagesize + scope.$index + 1}}</span>
        </template>
      </el-table-column> -->
      <el-table-column prop="_id" label="落地页ID">
      </el-table-column>
      <el-table-column prop="name" label="落地页名称">
      </el-table-column>
      <el-table-column prop="createdate" label="创建时间">
      </el-table-column>
      <el-table-column prop="type" label="落地页类别">
      </el-table-column>
      <el-table-column label="操作" width="120" align="center">
            <template slot-scope="scope">
              <el-dropdown placement="bottom" trigger="click">
                <span style="cursor:pointer" class="el-dropdown-link">
                  <i style="color:black!important" class="el-icon-more"></i>
                </span>
                <el-dropdown-menu  class="noselect" slot="dropdown">
                  <!-- <el-dropdown-item v-if="scope.row.reviewStatus == 101" @click.native="handleDetails(scope.$index,scope.row)">编辑广告</el-dropdown-item> -->
                  <el-dropdown-item @click.native="edit_dialog(scope.row)">编辑落地页</el-dropdown-item><!--v-else -->
                  <el-dropdown-item @click.native="handleDetails(scope.$index,scope.row)">复制落地页</el-dropdown-item>
                  <el-dropdown-item id="delPage" @click.native="delPage(scope.$index,scope.row)">删除落地页</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </template>
          </el-table-column>
      <el-table-column prop="remarks" label="备注" width="280px">
      </el-table-column>
      <!-- <el-table-column fixed="right" label="操作" width="185px">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-edit" size="small" @click="edit_dialog(scope.row)"></el-button>
          <el-button type="danger" icon="el-icon-delete" size="small" @click="remove(scope.row)"></el-button>
        </template>
      </el-table-column> -->
    </el-table>

    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination background layout="prev, pager, next" :total="100" :disabled="loading">
      </el-pagination>
    </div>

  </div>

</template>

<script>
  import utils from '../utils'//引入过滤方法
  export default {
    data() {
      return {
        //新建员工表单
        new_form_dialogVisible: false,
        new_form: {
          userName: '',
          realName: '',
          sex: '',
          phoneNumber: '',
          email: '',
          post: '',
          leader: '',
          status: '',
          type: '',
          password: '',
          remarks: ''
        },
        // 详情抽屉
        table: false,
        // 批量删除
        multipleSelectionFlag_delete:false,//删除按钮出现与否
        multipleSelection_delete:'',//选中项
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载界面显示与否
        loading: true,
        // 过滤后数据
        ShowTableData: [],
        // 原始数据
        tableData: [],
        //表单选项
        chooseType_dialog: [],
        chooseStatus_dialog: [],
        chooseLeader_dialog: [],
        chooseSex_dialog: [],
        // 搜索所属部门选项
        chooseDepartment: [],
        // 搜索状态选项
        chooseStatus: [],
        //搜索记录
        searchParams: {
          searchDate:null,
          searchObject:null,
          searchName:null,
          searchGroup:null,
          searchCountry:null,
          accurateSearch:null,
        },
        // 按钮权限
        buttonAuthority: {
          searchGroupAuthority:true,
          searchNameAuthority:true,
          searchObjectAuthority:true,
        },
        // 搜索角色类型选项
        chooseType: [],
        options: [
          {
          value: 'tuiguang',
          label: '推广部',
          children: [{value: 'zhuguan',label: '主管'}, 
            {value: 'xiangmuzuzhang',label: '项目组长'},
            {value: 'tuiguangyuan',label: '推广员'}, 
            {value: 'xiangmufuzeren',label: '项目负责人'},
            {value: 'codtuiguangyuan',label: 'COD推广员'}, 
            {value: 'codzuzhang',label: 'COD组长'}]
          }, 
          {
          value: 'shujubu',
          label: '数据部',
          children: [{value: 'shujubuzhuanyuan',label: '数据部专员'}, 
            {value: 'shujubuzuzhang',label: '数据部组长'},
            {value: 'shujuguanliyuan',label: '数据管理员'}, 
            {value: 'ceshi',label: '测试'}]
          },
          {
          value: 'yunyingbu',
          label: '运营部',
          children: [{value: 'yunyingbuzuzhang',label: '运营部组长'}]
          }, 
          {
          value: 'caiwubu',
          label: '财务部',
          children: [{value: 'caiwu',label: '财务'}]
          }, 
          {
          value: 'mxtuiguangbu',
          label: 'MX推广部',
          children: [{value: 'mx-codtuiguangyuan',label: 'MX-COD推广员'}, 
            {value: 'mx-codzuzhang',label: 'MX-COD组长'},
            {value: 'mxzhuguan',label: 'MX主管'}]
          },
        ],
      }
    },

    created() {
      // 执行网络请求
      this.fetch()
    },

    methods: {
      async delPage(index,e) {
        this.$confirm('是否删除该页面？').then( async()=> {
          var data = {
            "_id": e._id
          }
          console.log(data);
          await this.$http.post('http://localhost:3000/sys/api/pagedel',data).then((res)=> {
            console.log(res);
            if (res.status === 200) {
              this.$message.success('已删除')
              this.fetch()
            } else {
              this.$message.success('删除失败')
            }
          })
        }).catch(()=> {
          this.$message('已取消')
        });
      },
      //--------------------------------------------------------------
      // 批量删除(待添加async await)
      handleSelectionChange_delete(val) {//有选中项目时触发
          console.log(val); 
          this.multipleSelection_delete = val;
          this.multipleSelectionFlag_delete = true;
          if (this.multipleSelection_delete.length == 0) {   
            // 如不进行判断则勾选完毕后批量删除按钮还是会在
            this.multipleSelectionFlag_delete = false;
          }
      },
      search() {
        console.log(this.searchParams);
      },
      handleDetails (index, row) {
        console.log(index,row)  
      },
      //编辑表单
      async edit_dialog(e) {
        var data = {
          "_id": e._id
        }
        await this.$http.post('http://localhost:3000/sys/api/editpage',data).then((res)=> {
          this.$store.commit('storePageContent', {content:res.data[0].content, filename:res.data[0].filename,  pageName:res.data[0].name, pageType:res.data[0].type});
          this.$router.push('/tynimceeditor')
          console.log(this.$store.state.data);
        })
      },
      // -----------------------------------------------------------
      //表单提交
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
        });
      },
      // -----------------------------------------------------------
      //复制
      onCopy(e){
        this.$message({
          message:'复制成功！',
          type:'success'
        })
      },
      
      onError(e){
        this.$message({
          message:'复制失败！',
          type:'error'
        })
      },
      //--------------------------------------------------------------
      // 搜索-顺序执行筛选方法数组中的方法(input框code为0;日期筛选code为1,无code默认为下拉筛选框)
      utils_run() {
        var _this = this
        this.ShowTableData = this.tableData// 触发搜索前重新赋值原始数据
        utils.multiplexFilter(_this,this.searchDepartment, 'department')
        utils.multiplexFilter(_this,this.searchRealName, 'realname', 0)
        utils.multiplexFilter(_this,this.searchName, 'name', 0)
      },
      //--------------------------------------------------------------
      // 批量删除(待添加async await)
      // handleSelectionChange_delete(val) {//有选中项目时触发
      //     console.log(val); 
      //     this.multipleSelection_delete = val;
      //     this.multipleSelectionFlag_delete = true;
      //     if (this.multipleSelection_delete.length == 0) {   
      //       // 如不进行判断则勾选完毕后批量删除按钮还是会在
      //       this.multipleSelectionFlag_delete = false;
      //     }
      // },
      multiDelete() {//点击批量删除时触发
        let checkArr = this.multipleSelection_delete;//multipleSelection存储了勾选到的数据
        let params = [];//传给后端的删除项id
        let showDeleteItems = []
        checkArr.forEach(function (item) {     
          params.push(item._id);       // 添加所有需要删除数据的id到一个数组，post提交过去
          showDeleteItems.push(item.realname)
        });
        console.log(params);
        // 弹窗提示
        this.$confirm(`是否删除员工: ${showDeleteItems}`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            this.$message({
              type: "success",
              message: "删除成功(等待接口)",
            });
            // await this.$http.delete(`rest/ads/${row._id}`);
            // this.$message({
            //   type: "success",
            //   message: "删除成功!",
            // });
            // this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
        // 有接口时解开
        // let self = this;
          // 有接口时解开
        //  $http即是axios，可以在main.js里面设置 Vue.prototype.$http = axios;
        // this.$http.post('/fashion/multiDelete', params).then(function (res) {
        //   if (res.data.status == '1') {
        //     self.$message({
        //       message: '删除成功',
        //       type: 'success'
        //     });
        //   }
        //   self.getFashionList(1, 1, 5);
        // })
      },
      //--------------------------------------------------------------
      // 权限详情
      tableOpen(e) {
        console.log(e);
        this.table = true
      },
      //--------------------------------------------------------------
      // 数据获取
      async fetch() {
        await this.$http.get("http://localhost:3000/sys/api/landingpagelist").then((res)=> {
          this.ShowTableData = res.data
          this.loading = false
        })
        // this.$http.post("http://localhost:3000/sys/api/test",'aaa').then((res)=> {
        //   // console.log(res);
        // })
      //   this.$http.get('/emloyeemanagement.json').then((res) => {// 获取数据
      //   this.chooseType_dialog = res.data.new_form_type
      //   this.chooseStatus_dialog = res.data.new_form_status
      //   this.chooseSex_dialog = res.data.new_form_sex
      //   this.chooseLeader_dialog = res.data.new_form_leader

      //   this.tableData = res.data.EmployeeList//保留原数据
      //   this.ShowTableData = this.tableData//原数据赋值给展示的表格数据
        
      //   //根据数据填充下拉选项-部门
      //   this.tableData.forEach(item => {
      //     this.chooseDepartment.push(item.department)
      //   })
      //   this.chooseDepartment = [...new Set(this.chooseDepartment)]


      //   //数据完成展示后取消加载页面
      //   this.loading = false
      // })

      },
      //--------------------------------------------------------------
      // 移除单项
      async remove(row) {
        this.$confirm(`是否删除 ${row.realname}`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            await this.$http.delete(`rest/ads/${row._id}`);
            this.$message({
              type: "success",
              message: "删除成功!",
            });
            this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
      },
    },
  }
</script>

<style scoped>
  .el-dropdown-menu__item {
    text-align: center;
  }
  .el-button--info {
    background-color: white!important;
    color: #606266!important;
  }
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
      /* color: rgb(65, 181, 132) !important; */
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
  .el-button--primary {
      color: rgb(41, 42, 45) !important;
      background-color: #fff !important;
      border-color: rgb(41, 42, 45) !important;
  }

  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(77, 77, 77) !important;
      border-color: rgb(77, 77, 77) !important;
  }
    .el-select {
    display: block!important;
  }
  #delPage:hover {
    color:rgb(245,108,108);
    background-color:rgb(254,240,240)
  }
</style>
