<template>
  <div >
    <!-- 搜索框 -->
    <div style="display: flex;position:relative;margin-bottom: 30px;min-width:400px">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display: flex; flex-wrap: wrap;width:100%;justify-content: space-between" :disabled="loading">
        <el-form-item class="noselect">
          <!-- <el-input v-model="searchParams.accurateSearch" placeholder="搜索域名" clearable style="width: 200px;margin-right:10px"></el-input>
          <el-button @click="search" type="info" style="height: 30px; position: relative; margin-top: 32px">搜索</el-button> -->
          <el-button class="info_btn" @click="groupmanagement_dialog = true" type="info" style="height: 30px; position: relative; margin-top: 32px">分组管理</el-button>
          <el-button class="info_btn" @click="new_role_dialog" type="info" style="height: 30px; position: relative; margin-top: 32px">新建角色</el-button>
        </el-form-item>

      </el-form>
    </div>

    <!-- 表格 -->
    <el-table
      :height="tableHeight"
      :key="key"
      stripe
      v-loading="loading"
      element-loading-background="rgba(255,255,255,0.9)"
      ref="multipleTable"
      :data="ShowTableData"
      tooltip-effect="dark"
      style="width:calc(100%-60px);line-height:30px;margin:25px 0px;min-width:700px"
      border>
      <!-- <el-table-column type="selection" width="55"></el-table-column> -->
      <el-table-column prop="" label="详情" width="50px">
        <template slot-scope="scope">
          <el-button
            type="text" icon="el-icon-arrow-right"
            size="small"
            @click="tableOpen(scope.row)"
            style="padding-left: 9px;color:#909399"
          ></el-button>
        </template>
      </el-table-column>
      <el-table-column prop="role_name" label="角色名称"></el-table-column>
      <el-table-column prop="group" label="所属分组"></el-table-column>
      <el-table-column prop="create_time_change" label="创建时间"></el-table-column>
      <!-- <el-table-column fixed="right" label="操作" width="150px">
        <template slot-scope="scope">
          <el-button :disabled="scope.row.use_in === '1' ? true:false" type="text" size="small" @click="edit_role_dialog(scope.row)">编辑</el-button>
          <el-button style="color:#F56C6C" :disabled="scope.row.use_in === '1' ? true:false" type="text" size="small" @click="delRole(scope.row)">删除</el-button>
        </template>
      </el-table-column> -->

      <el-table-column fixed="right" label="操作" align="center" width="130px">
        <template slot-scope="scope">
          <el-dropdown placement="bottom" trigger="click">
            <span style="cursor: pointer;" class="el-dropdown-link">
              <i style="color: grey!important" class="el-icon-more"></i>
            </span>
            <el-dropdown-menu class="noselect" slot="dropdown">
              <el-dropdown-item :disabled="scope.row.use_in === '1' ? true:false" type="text" size="small" @click.native="edit_role_dialog(scope.row)">编辑角色</el-dropdown-item>
              <el-dropdown-item id="delUser" :disabled="scope.row.use_in === '1' ? true:false" type="text" size="small" @click.native="delRole(scope.row)">删除角色</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <!-- <div class="block" style="position: relative; right: 0px; margin-bottom: 80px;min-width:1500px">
      <el-pagination :page-size="20" background @current-change="fetchPageData()" :current-page.sync="currentPage" layout="prev, pager, next" :total="totalNum" :disabled="loading">
      </el-pagination>
    </div> -->

    <!-- 详情抽屉 -->
    <el-drawer class="noselect" title="详情" :visible.sync="table" direction="rtl" size="600px">
      <el-form ref="makeOver_form" label-width="100px" label-position="left" style="padding-left: 70px" v-loading="loadingDetail">
        <el-form-item size="small" label="权限详情: " class="noselect">
          <el-tree
            style="margin-top:3px"
            ref="showTree"
            node-key="value"
            :props="showTreeprops"
            :data="data"
            :show-checkbox="true"
            :load="loadNode"
            :check-on-click-node="true">
          </el-tree>
        </el-form-item>
      </el-form>
    </el-drawer>

    <!-- 分组管理 -->
    <el-dialog title="分组管理" :visible.sync="groupmanagement_dialog" width="700px" :close-on-click-modal="false">
      <div style="position:relative;width:100%;height:50px">
        <el-button style="position:absolute;left:7px"  @click="newgroup_dialog = true" type="text">新建组别</el-button>
      </div>
        <el-table :data="group_list">
          <el-table-column property="group" label="分组" width="200px"></el-table-column>
          <el-table-column property="group" label="子组"></el-table-column>
          <el-table-column label="操作" width="100px">
            <template slot-scope="scope">
              <el-button type="text" style="color:rgb(245, 108, 108);" size="small" @click="del_grop(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
    </el-dialog>

    <el-dialog title="新建分组" :visible.sync="newgroup_dialog" width="400px" :close-on-click-modal="false">
      <el-form label-width="80px" label-position="right">
        <el-form-item  label="分组名称" class="noselect" style="margin-right:240px" prop="new_form_account">
          <el-input v-model="newgroup_dialog_name" placeholder="请输入内容" style="width:240px">
          </el-input>
        </el-form-item>
          <el-button :disabled="newgroup_dialog_name === ''?true:false" size="small" type="primary" @click="newgroup_dialog_submit_allow()" class="formSubmitBtn" style="margin-right: -220px;">确 认</el-button>
      </el-form>
    </el-dialog>

    <!-- 创建角色表单 -->
    <el-dialog title="创建角色" :visible.sync="new_role_dialogVisible" width="400px" :close-on-click-modal="false">
      <el-form label-width="100px" label-position="right">
        <el-form-item label="选择分组" class="noselect" style="margin-right: 40px">
          <el-select v-model="new_role_dialog_params.group" filterable placeholder="筛选" clearable>
            <el-option v-for="(item,index) in group_list" :key="index" :label="item['group']" :value="item['group']"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="角色名称" class="noselect" style="margin-right:240px" prop="new_form_account">
          <el-input v-model="new_role_dialog_params.role" placeholder="请输入内容" style="width:220px">
            </el-input>
        </el-form-item>
        <el-form-item label="权限限制"  class="noselect">
          <el-tree
            style="margin-top:5px"
            ref="tree"
            :props="props"
            :data="data"
            node-key="value"
            :show-checkbox="true"
            :load="loadNode"
            :check-on-click-node="true">
          </el-tree>
        </el-form-item>
        <el-button :disabled="new_role_dialog_params.group === ''|| new_role_dialog_params.role ==='' ? true:false" @click="new_role_dialog_submit" size="small" type="primary" class="formSubmitBtn" style="margin-right: -220px" >确 定</el-button>
      </el-form>
    </el-dialog>

    <!-- 编辑角色表单 -->
    <el-dialog title="编辑角色" :visible.sync="edit_role_dialogVisible" width="400px" :close-on-click-modal="false">
      <el-form :model="edit_role_dialog_params" label-width="100px" label-position="right">
        <el-form-item label="选择分组" class="noselect" style="margin-right: 40px">
          <el-select v-model="edit_role_dialog_params.group" filterable placeholder="筛选">
            <el-option v-for="(item,index) in group_list" :key="index" :label="item['group']" :value="item['group']"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="角色名称" class="noselect" style="margin-right:240px" prop="new_form_account">
          <el-input v-model="edit_role_dialog_params.role" placeholder="请输入内容" style="width:220px">
            </el-input>
        </el-form-item>
        <el-form-item label="权限限制"  class="noselect">
          <el-tree
            style="margin-top:5px"
            ref="editTree"
            :props="props"
            :data="data"
            node-key="value"
            :show-checkbox="true"
            :load="loadNode"
            :check-on-click-node="true">
          </el-tree>
        </el-form-item>
        <el-button :disabled="edit_role_dialog_params.group === ''|| edit_role_dialog_params.role ==='' ? true:false" @click="edit_role_dialog_submit" size="small" type="primary" class="formSubmitBtn" style="margin-right: -220px" >确 定</el-button>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import utils from '../utils'
export default {
  data() {
    return {
      tableHeight:620,
      checkNodeKeys:[],
      props: {
      children: "children",
      label: "label",
      },
      showTreeprops: {
        children: "children",
        label: "label",
        disabled: this.disabledFn
      },
      data:[
          {
            label: "页面A",
            value:"pageA",
            children: [
              {
                label: "按钮权限A",
                value:"btnA",
              },
            ],
          },
          {
            label: "页面B",
            value:"pageB",
            children: [
              {
                label: "按钮权限B",
                value:"btnB",
              },
              {
                label: "按钮权限C",
                value:"btnC",
              },
            ],
          },
          {
            label: "页面C",
            value:"pageC",
            children: [
              {
                label: "按钮权限D",
                value:"btnD",
              },
              {
                label: "按钮权限E",
                value:"btnE",
              },
            ],
          },
      ],
      // 新建角色
      new_role_dialogVisible:false,
      new_role_dialog_params: {
        group:'',
        role:'',
        authority:[],
      },
      // 编辑角色
      edit_role_dialogVisible:false,
      edit_role_dialog_params: {
        group:'',
        role:'',
        authority:[]
      },
      // 分组列表
      newgrop_btn_diabled:true,
      newgroup_dialog:false,
      groupmanagement_dialog:false,
      group_list: null,
      newgroup_dialog_name: '',
      key: 0,
      // 加载界面显示与否
      loading: false,
      loadingDetail:false,
      // 过滤后数据
      ShowTableData: [],
      // 原始数据
      tableData: [],
      //搜索记录
      searchParams: {
        accurateSearch: '',
      },
      // 详情抽屉
      table: false,
      // 分页
      totalNum: 10,
      currentPage: 1,
      useSearchData: false,
      //详情
      detail_subDomain: [],
    };
  },

  created() {
    this.fetch();
    this.fetchGroupData()
  },

  methods: {
    async fetchPageData() {// 点击页码
      this.loading = true;
      if (this.useSearchData === false) {
        let formData = new FormData();
        formData.append("page", this.currentPage);
        formData.append("user",1000)
        await this.$http.post("/index.php/index/domain/domainStock/",formData).then((res) => {
        res.data["domain"].forEach(e=> {
          e["create_time_change"] = utils.getLocalTime(parseInt(e["create_time"]));
          e["apply_time_change"] = utils.getLocalTime(parseInt(e["apply_time"]));
          e["expiring_time_change"] = utils.getLocalTime(parseInt(e["expiring_time"]));
        })
        this.ShowTableData = res.data["domain"]
        this.loading = false;
          });
      } else {
          this.ShowTableData = [];
          this.tableData.forEach((e) => {
            if (
              this.tableData.indexOf(e) <= (this.currentPage - 1) * 20 + 19 &&
              this.tableData.indexOf(e) >= (this.currentPage - 1) * 20
            ) {
              this.ShowTableData.push(e);
            }
          });
          this.loading = false;
        }
        this.getTableHeight()
    },
    async search() {// 搜索
      this.loading = true;
      this.useSearchData = true;
      this.currentPage = 1;
      let formData = new FormData();
      formData.append("domain",this.searchParams.accurateSearch)
      formData.append("user",1000)
      if (this.searchParams.accurateSearch === null || this.searchParams.accurateSearch === '') {
        this.useSearchData = false;
        this.fetch()
      } else {
          await this.$http.post("/index.php/index/domain/domainSearch/",formData).then((res) => {
          this.tableData = res.data["subDomain"]
          this.totalNum = res.data["subDomain"].length
          res.data["subDomain"].forEach(e=> {
            e["create_time_change"] = utils.getLocalTime(parseInt(e["create_time"]));
            e["apply_time_change"] = utils.getLocalTime(parseInt(e["apply_time"]));
            e["expiring_time_change"] = utils.getLocalTime(parseInt(e["expiring_time"]));
          })
          this.ShowTableData =[]
          if (res.data["subDomain"].length <=20) {
            for (let i = 0; i < res.data["subDomain"].length; i++) {
              this.ShowTableData.push(res.data["subDomain"][i])
            }
          } else {
              for (let i = 0; i < 20; i++) {
                this.ShowTableData.push(res.data["subDomain"][i])
              }
          }
          this.loading = false;
        });
      }
      this.getTableHeight()
    },
    onCopy() {// 复制成功
      this.$message.success('复制成功')
    },
    onError() {// 复制失败
      this.$message.error('复制失败')
    },
    tableOpen(e) {// 详情
      this.table = true;
      this.loadingDetail = true
      setTimeout(() => {
        for (let i = 0; i < this.data.length; i++) {
          this.$refs.showTree.store.nodesMap[this.data[i].value].expanded = false;
        }
        this.$refs.showTree.setCheckedKeys([])
        e.checkItems.forEach(i=> {
          this.$nextTick(()=> {
            this.$refs.showTree.setChecked(i,true,false)
          })
        })
        this.loadingDetail = false
      }, 1);
    },
    async fetch() {// 数据获取
      this.loading = true
      let formData = new FormData()
      formData.append("user",1000)
      await this.$http.post("/index.php/index/Role/roleList",formData).then((res) => {
        this.ShowTableData = res.data[0]
        res.data[0].forEach(e=> {
          e["checkItems"] = e.content.split(",")
          e["create_time_change"] = utils.getLocalTime(parseInt(e["create_time"]));
        })
        this.getTableHeight()
        this.loading = false;
      });
    },
    async newgroup_dialog_submit() {// 创建分组
      let formData = new FormData()
      formData.append("group",this.newgroup_dialog_name)
      await this.$http.post('/index.php/index/Role/addGroup',formData).then((res) => {
        if (res.data > 0) {
          this.$message.success('创建成功')
          this.fetchGroupData()
          this.newgroup_dialog = false
        } else {
          this.$message.error('创建失败')
        }
      })
    },
    newgroup_dialog_submit_allow() {//检验
      var allow_arr =[] 
      this.group_list.forEach(e=> {
        allow_arr.push(e["group"])
      })
      if (allow_arr.indexOf(this.newgroup_dialog_name) >= 0) {
        this.$message({
          type: "error",
          message: "已存在该分组",
        });
      } else {
        this.newgroup_dialog_submit()
      }
    },
    async fetchGroupData() { //获取分组信息
      this.loading = true
      await this.$http.get('/index.php/index/Role/groupList').then((res)=> {
        this.group_list = res.data
        this.loading = false
      })
    },
    async del_grop(e) {// 删除分组
      let formData = new FormData()
      formData.append("group",e.group)
      await this.$http.post('/index.php/index/Role/deleteGroup',formData).then((res) => {
        if (res.data > 0) {
          this.$message.success('删除成功')
          this.fetchGroupData()
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    async new_role_dialog_submit() {//新建角色提交
      let parentArr = this.$refs.tree.getHalfCheckedKeys()//获取半选中状态的value
      let childArr = this.$refs.tree.getCheckedKeys()//获取全选中的value
      this.checkNodeKeys = parentArr.concat(childArr)//拼接
      if (this.checkNodeKeys.length === 0) {
        this.$message({
          message: "权限不可为空",
          type: "error",
        });
      } else {
        this.new_role_dialog_params.authority =  this.checkNodeKeys
        let formData = new FormData()
        formData.append("group",this.new_role_dialog_params.group)
        formData.append("role",this.new_role_dialog_params.role)
        formData.append("authority",this.new_role_dialog_params.authority)
        await this.$http.post('/index.php/index/Role/addRole',formData).then((res)=> {
          if (res.data.code === 200) {
            this.$message.success(`${res.data.data}`)
          this.new_role_dialogVisible = false
          this.fetch()
          } else {
            this.$message.error(`${res.data.data}`)
          }
        })
      }
    },
    async edit_role_dialog_submit() {//编辑角色提交
      let parentArr = this.$refs.editTree.getHalfCheckedKeys()//获取半选中状态的value
      let childArr = this.$refs.editTree.getCheckedKeys()//获取全选中的value
      this.checkNodeKeys = parentArr.concat(childArr)//拼接
      if (this.checkNodeKeys.length === 0) {
        this.$message({
          message: "权限不可为空",
          type: "error",
        });
      } else {
        this.edit_role_dialog_params.authority =  this.checkNodeKeys
        let formData = new FormData()
        formData.append("group",this.edit_role_dialog_params.group)
        formData.append("role",this.edit_role_dialog_params.role)
        formData.append("authority",this.edit_role_dialog_params.authority)
        formData.append("id",this.edit_role_dialog_params.id)
        await this.$http.post('/index.php/index/Role/roleEdit',formData).then((res)=> {
          if (res.data.code === 200) {
            this.$message.success(`${res.data.data}`)
          this.edit_role_dialogVisible = false
          this.fetch()
          } else {
            this.$message.error(`${res.data.data}`)
          }
        })
      }
    },
    delRole(e) {//删除角色
      this.$confirm(`是否删除角色：${e.role_name}？`,{
        type:"warning"
      })
        .then(() => {
          console.log(e);
        })
        .catch(() => {
          this.$message("已取消");
        });
    },
    loadNode(node, resolve) {//渲染权限树
      resolve(this.data)
    },
    disabledFn() {//详情权限树禁用
      return true
    },
    edit_role_dialog(e) {//编辑角色表单
      this.edit_role_dialog_params.id = e.id
      this.edit_role_dialog_params["group"] = e.group
      this.edit_role_dialogVisible = true
      setTimeout(() => {
        this.$refs.editTree.setCheckedKeys([])
        this.edit_role_dialog_params.role = e.role_name
        e.checkItems.forEach(i=> {
          this.$nextTick(()=> {
            this.$refs.editTree.setChecked(i,true,false)
          })
        })
      }, 1);
    },
    new_role_dialog() {// 创建角色树
      this.new_role_dialogVisible = true
      setTimeout(() => {
              for (let i = 0; i < this.data.length; i++) {
        this.$refs.tree.store.nodesMap[this.data[i].value].expanded = false;
      }
      this.$refs.tree.setCheckedKeys([])
      }, 1);
    },
    getTableHeight() {//获取高度
      if (this.ShowTableData.length >= 11) {
        this.tableHeight = 11*53 + 56
      }  else if (this.ShowTableData.length === 0) {
        this.tableHeight = 120
      } else {
        this.tableHeight = this.ShowTableData.length*53 + 56
      }
    }
  },
};
</script>

<style scoped>
.el-tag.el-tag--info {
  background-color: white!important;
}
.iftop {
  color: #409EFF;
}
.iftop_not {
  color: grey;
}
.el-dropdown-menu__item {
  text-align: center;
}
.el-button--info {
  background-color: white !important;
  color: #606266 !important;
}
.is-active {
  background-color: white !important;
}
.el-select-dropdown__item.selected {
  /* color: rgb(65, 181, 132) !important; */
  font-weight: 700;
}
.el-main {
  line-height: 20px !important;
}
.el-button--primary {
  color: rgb(41, 42, 45) !important;
  background-color: #fff !important;
  border-color: rgb(41, 42, 45) !important;
}

.el-button--primary:hover {
  color: white !important;
  background-color: rgb(77, 77, 77) !important;
  border-color: rgb(77, 77, 77) !important;
}
.el-select {
  display: block !important;
}
.info_btn {
  background-color: #353639!important;
  color: white!important;
  border-color: #353639!important;
}
.info_btn:hover {
  background-color: #4D4D4D!important;
  border-color: #4D4D4D!important;
}
.el-button--primary.is-disabled {
  border-color: grey!important;
  color:grey!important;
  background-color: white!important;
}
.el-button--info.is-disabled {
  border-color: grey!important;
  color:grey!important;
  background-color: white!important;
}

.el-button--primary.is-disabled:hover {
  color: grey!important;
}
.el-button--info.is-disabled:hover{
  color: grey!important;
}
#delUser:hover {
  color: rgb(245, 108, 108);
  background-color: rgb(254, 240, 240);
}
</style>
