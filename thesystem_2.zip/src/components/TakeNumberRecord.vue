<template>
  <div>
    <!-- 表格 -->
    <el-table stripe v-loading="loading" element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 0" border>
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
        <span>{{(pageIndex - 1) * pagesize + scope.$index + 1}}</span>
    </template>
      </el-table-column>
      <el-table-column prop="_id" label="ID" width="100">
      </el-table-column>
      <el-table-column prop="date" label="时间" width="200">
      </el-table-column>
      <el-table-column prop="account" label="账号" width="200">
      </el-table-column>
      <el-table-column prop="user" label="用户" width="200px">
      </el-table-column>
    </el-table>
    
    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination
        :current-page="currentPage4"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400">
      </el-pagination>
    </div>
  </div>

</template>

<script>
  export default {
    data() {
      return {
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载页面显示与否
        loading: true,
        // 过滤后的数据
        ShowTableData: [],
      }
    },

    created() {
      this.fetch()
    },

    methods: {
      //--------------------------------------------------------------
      fetch() {
        this.$http.get('/accountmanagement.json').then((res) => {// 获取数据
          this.ShowTableData = res.data.importLog//保留原数据
          //数据完成展示后取消加载页面
          this.loading = false
        })
      },
    },
  }
</script>

<style scoped>
.el-main {
  line-height: 20px!important;
}
</style>
