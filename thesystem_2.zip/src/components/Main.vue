<template>
<div class="main"></div>
</template>

<script>
export default {
  props: {
  }
}
</script>

<style scoped lang="scss">
  .main {
    width: 100%;
    // height: 400px;
    margin-top: 300px!important;
    background-image: url('../assets/logo.c98dd38b.webp');
    position: absolute;
    top: -250px;
    right: 0;
    bottom: 0;
    margin: auto;
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
  }
</style>
