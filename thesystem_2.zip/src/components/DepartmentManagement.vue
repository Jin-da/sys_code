<template>
  <div>
    <!-- 搜索框 -->
    <div style=" display: flex;position:relative;margin-left:30px;">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap">
        <el-form-item class="noselect" label="部门名称">
          <el-input @change="utils_run" v-model="searchDepartment" placeholder="请输入搜索内容" clearable style="height: 32px">
          </el-input>
        </el-form-item>
        <!-- <el-form-item>
          <el-button  @click="onSubmit" type="primary" icon="el-icon-search" style="height: 30px;background-color: rgb(65, 181, 132) !important;color:white!important;border-color: white!important "></el-button>
        </el-form-item> -->
        <el-form-item>
          <el-button   @click="dialogVisible_new = true" type="primary" icon="el-icon-plus" style="height: 30px">新建部门</el-button>
        </el-form-item>
        <el-form-item>
          <transition name="el-fade-in-linear">
            <el-button type="danger" class="multipleSelection_delete_btn" v-show="multipleSelectionFlag_delete" @click="multiDelete()" icon="el-icon-minus" style="height: 30px;color:rgb(245,108,108);background-color:white">批量删除选中项</el-button>
          </transition>
        </el-form-item>
      </el-form>
    </div>

    <!--新建项目表单  -->
    <el-dialog title="新建部门" :visible.sync="dialogVisible_new" width="30%">
      <el-form ref="form" :model="new_form" label-width="80px">
        <el-form-item label="部门名称">
          <el-input v-model="new_form.DepartmentName" placeholder="请输入部门名称"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="formSubmit_new" class="formSubmitBtn">确 定</el-button>
      </span>
    </el-dialog>
    
    <!-- 编辑项目表单 -->
    <el-dialog title="编辑部门名称" :visible.sync="dialogVisible_edit" width="30%">
      <el-form ref="form" :model="edit_form" label-width="80px">
        <el-form-item label="部门名称">
          <el-input v-model="edit_form.DepartmentName"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="formSubmit_edit" class="formSubmitBtn">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 表格 -->
    <el-table stripe v-loading="loading" element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 0" border @selection-change="handleSelectionChange_delete">
      <el-table-column type="selection" width="55">
      </el-table-column>
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
        <span>{{(pageIndex - 1) * pagesize + scope.$index + 1}}</span>
    </template>
      </el-table-column>
      <el-table-column prop="date" label="创建时间" width="200">
      </el-table-column>
      <el-table-column prop="department" label="部门名称">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="300px">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-edit" size="small" @click="dialogVisible_edit_method(scope.row)"></el-button><!--scope.row表示当前行的数据    @click="$router.push(`/ads/edit/${scope.row._id}`)"-->
          <el-button type="danger" icon="el-icon-delete" size="small" @click="remove(scope.row)"></el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination
        :current-page="currentPage4"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400">
      </el-pagination>
    </div>
  </div>

</template>

<script>
  import utils from '../utils'//引入过滤方法
  export default {
    data() {
      return {
        // 批量删除
        multipleSelectionFlag_delete:false,//删除按钮出现与否
        multipleSelection_delete:'',//选中项
        // 表单
        dialogVisible_new:false,
        dialogVisible_edit:false,
        new_form: {
          DepartmentName: '',
        },
        edit_form: {
          DepartmentName: '',
        },
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载页面显示与否
        loading: true,
        // 过滤后的数据
        ShowTableData: [],
        // 原数据
        tableData: [],
        // 搜索输入框记录
        searchDepartment: '',
      }
    },

    created() {
      this.fetch()
      console.log('aaa');
    },

    methods: {
      //--------------------------------------------------------------
      // 搜索-顺序执行筛选方法数组中的方法(input框code为0;日期筛选code为1,无code默认为下拉筛选框)
      utils_run() {
        var _this = this
        this.ShowTableData = this.tableData// 触发搜索前重新赋值原始数据
        utils.multiplexFilter(_this,this.searchDepartment, 'department', 0)
      },
      //--------------------------------------------------------------
      // 编辑菜单显示
      dialogVisible_edit_method(row) {
        this.dialogVisible_edit = true
        this.edit_form.DepartmentName = row.department
      },
      //--------------------------------------------------------------
      // 单项选中移除
      async remove(row) {
        this.$confirm(`是否删除 ${row.department}`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            // await this.$http.delete(`rest/ads/${row._id}`);
            this.$message({
              type: "success",
              message: "删除成功!",
            });
            this.dialogVisible_edit = false
            // this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
      }, 
      //--------------------------------------------------------------
      // 批量删除(待添加async await)
      handleSelectionChange_delete(val) {//有选中项目时触发
          console.log(val); 
          this.multipleSelection_delete = val;
          this.multipleSelectionFlag_delete = true;
          if (this.multipleSelection_delete.length == 0) {   
            // 如不进行判断则勾选完毕后批量删除按钮还是会在
            this.multipleSelectionFlag_delete = false;
          }
      },
      multiDelete() {//点击批量删除时触发
        let checkArr = this.multipleSelection_delete;//multipleSelection存储了勾选到的数据
        let params = [];//传给后端的删除项id
        let showDeleteItems = []
        checkArr.forEach(function (item) {     
          params.push(item._id);       // 添加所有需要删除数据的id到一个数组，post提交过去
          showDeleteItems.push(item.department)
        });
        console.log(params);
        // 弹窗提示
        this.$confirm(`是否删除部门: ${showDeleteItems}`, "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(async () => {
            this.$message({
              type: "success",
              message: "删除成功(等待接口)",
            });
            // await this.$http.delete(`rest/ads/${row._id}`);
            // this.$message({
            //   type: "success",
            //   message: "删除成功!",
            // });
            // this.fetch();
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
        // 有接口时解开
        // let self = this;
          // 有接口时解开
        //  $http即是axios，可以在main.js里面设置 Vue.prototype.$http = axios;
        // this.$http.post('/fashion/multiDelete', params).then(function (res) {
        //   if (res.data.status == '1') {
        //     self.$message({
        //       message: '删除成功',
        //       type: 'success'
        //     });
        //   }
        //   self.getFashionList(1, 1, 5);
        // })
      },
      //--------------------------------------------------------------
      //新项表单提交 
      formSubmit_new() {
        this.dialogVisible_new = false
        console.log('表单提交: ' + this.new_form.DepartmentName);
        // 此时进行提交post操作
      },
      //--------------------------------------------------------------
      //编辑表单提交 
      formSubmit_edit() {
        this.dialogVisible_edit = false
        console.log('表单提交: ' + this.edit_form.DepartmentName);
        // 此时进行提交post操作
      },
      //--------------------------------------------------------------
      fetch() {
        this.$http.get('/test.json').then((res) => {// 获取数据
          this.tableData = res.data.departmentTableData//保留原数据
          this.ShowTableData = this.tableData//原数据赋值给展示的表格数据

          //数据完成展示后取消加载页面
          this.loading = false
        })
      },
    },
  }
</script>

<style scoped>
.el-main {
      line-height: 20px!important;
}
.el-button--primary {
    color: rgb(65, 181, 132) !important;
    background-color: #fff !important;
    border-color: rgb(65, 181, 132) !important;
}


  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(65, 181, 132) !important;
      border-color: rgb(65, 181, 132) !important;
  }


  /*弹出框表单样式 */
  .el-dialog__body {
    padding-left: 30px!important;
    padding-right: 30px!important;
    padding-bottom: 0!important;
  }
  .el-dialog__footer {
    padding-top: 0!important;
    padding-right: 30px!important;
  }
  .formSubmitBtn {
        width: 70px;
    height: 35px;
    padding: 0!important;
  }
.formSubmitBtn:hover{
      background-color: rgb(65, 181, 132)!important;
      color: white!important;
}



</style>
