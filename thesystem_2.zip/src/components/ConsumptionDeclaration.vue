<template>
  <div>
    <!-- 搜索框 -->
    <div style=" display: flex;position:relative;margin-left: 30px;">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap">
        <el-form-item label="账户" class="noselect">
          <el-select filterable @change="utils_run" v-model="searchAccount" placeholder="快捷搜索" clearable style="width:200px">
            <el-option v-for="item in chooseAccount" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item class="noselect">
          <el-button type="info" icon="el-icon-plus" style="height: 30px" @click="new_form_methods">自主申报</el-button>
        </el-form-item>
        <el-form-item class="noselect">
          <el-button type="info" icon="el-icon-edit" :disabled="showIf" style="height: 30px" @click="multiple_form_methods">批量设置</el-button>
        </el-form-item>
                <el-form-item class="noselect">
          <el-button type="info" icon="el-icon-upload2" :disabled="showIf" style="height: 30px" @click="multiple_form_submit">批量申报</el-button>
        </el-form-item>
        <el-form-item>
          <el-tooltip class="item" effect="dark" content="申报前后请一定检查申报日期！！" placement="top">
            <el-button
                type="text" icon="el-icon-info"
                size="small"
                style="color:#909399;font-size:15px;padding-top:0px"
            ></el-button>
          </el-tooltip>
        </el-form-item>
        <!-- <p style="line-height: 30px;margin-bottom: 18px;" class="noselect">申报前后请一定检查申报日期！！</p> -->
      </el-form>
    </div>

    <!-- 表格 -->
    <el-table :default-sort = "{prop: 'date', order: 'descending'}" stripe :header-cell-style="getRowClass" :cell-style="setCellColor" v-loading="loading" element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 0" border @selection-change="handleSelectionChange_delete">
      <el-table-column type="selection" width="55">
      </el-table-column>
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
          <span>{{(pageIndex - 1) * pagesize + scope.$index + 1}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="date" label="消耗日期" width="200px" sortable>
        <!-- <template slot-scope="scope">
          <el-date-picker
            disabled
            v-model="scope.row.date"
            type="date">
          </el-date-picker>
        </template> -->
      </el-table-column>
      <el-table-column prop="account" label="账户" width="350px">
      </el-table-column>
      <el-table-column prop="_id" label="ID" width="150px">
      </el-table-column>
      <el-table-column prop="currency" label="币种" width="150px">
      </el-table-column>
      <el-table-column prop="project" label="项目" width="185px">
      </el-table-column>
      <el-table-column prop="amount" label="消耗金额" width="80px">
      </el-table-column>
      <!-- <el-table-column label="消耗凭证" width="80px">
        <div class="demo-image__preview" style="position:relative">
          <el-image 
            style="width: 40px;height: 40px; opacity: 0;position:absolute"
            :src="url" 
            :preview-src-list="srcList">
          </el-image>
            <el-button
              type="text" icon="el-icon-full-screen"
              size="small"
              :preview-src-list="srcList"
              style="padding-left: 9px;color:#909399;font-size:20px"
            ></el-button>
        </div>
      </el-table-column> -->
      <el-table-column prop="remarks" label="备注">
      </el-table-column>
      <el-table-column  label="操作">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-edit" @click="edit_form_methods(scope.row)" size="small"></el-button><!--scope.row表示当前行的数据-->
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination
        :current-page="currentPage4"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400">
      </el-pagination>
    </div>

    <!--编辑表单  -->
    <el-dialog :visible.sync="edit_form_dialogVisible" width="600px" label-width="80px">
      <el-form ref="edit_form" :model="edit_form" label-width="80px" label-position="right">
        <el-form-item size="small" label="项目" class="noselect" style="margin-right:240px" prop="edit_form_type">
          <el-select  v-model="edit_form.project" placeholder="请选择项目" clearable>
            <el-option v-for="item in chooseProject" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="消耗金额" class="noselect" style="margin-right:240px" prop="limit">
            <el-input v-model="edit_form.amount"  style="position: absolute;left: 0"></el-input>
        </el-form-item>
        <el-form-item size="small" label="备注" class="noselect" style="margin-right:240px">
            <el-input v-model="edit_form.remarks"  style="position: absolute;left: 0"></el-input>
        </el-form-item>
        <el-form-item size="small" label="消耗凭证" class="noselect" style="margin-right:300px;position:relative">
          <span style="color:red;position:absolute;left:-77px">*</span>
          <el-upload
          required
            class="avatar-uploader"
            action=''
            :show-file-list="false"
            :auto-upload="false"
            :on-change="getFile_edit">
            <img v-if="imageUrl_edit" :src="imageUrl_edit" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
          <el-button size="small" type="primary" @click="submitForm_pic('edit_form')" class="formSubmitBtn" style="margin-right: 340px;">申 报</el-button>
      </el-form>
    </el-dialog>

    <!--新建表单  -->
    <el-dialog title="自主申报" :visible.sync="new_form_dialogVisible" width="600px">
      <el-form :rules="rules" ref="new_form" :model="new_form" label-width="80px" label-position="right">
        <el-form-item size="small" label="消耗日期" class="noselect" style="margin-right:240px" prop="new_form_date">
          <el-date-picker v-model="new_form.new_form_date" type="date" placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item size="small" label="项目" class="noselect" style="margin-right:240px">
          <el-select  v-model="new_form.new_form_project" placeholder="筛选" clearable>
            <el-option v-for="item in chooseProject" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="账户" class="noselect" style="margin-right:240px" prop="new_form_account">
          <el-input v-model="new_form.new_form_account" placeholder="请输入内容" clearable style="width:240px">
          </el-input>
        </el-form-item>
        <el-form-item size="small" label="ID" class="noselect" style="margin-right:240px" prop="new_form_id">
          <el-input v-model="new_form.new_form_id" placeholder="请输入内容" clearable style="width:240px">
          </el-input>
        </el-form-item>
        <el-form-item size="small" label="币种" class="noselect" style="margin-right:240px">
          <el-input v-model="new_form.new_form_currency" placeholder="请输入内容" clearable style="width:240px">
          </el-input>
        </el-form-item>
        <el-form-item size="small" label="消耗金额" class="noselect" style="margin-right:240px">
          <el-input v-model="new_form.new_form_amount" placeholder="请输入内容" clearable style="width:240px">
          </el-input>
        </el-form-item>
        <el-form-item size="small" label="备注" class="noselect" style="margin-right:240px">
          <el-input v-model="new_form.new_form_remarks" placeholder="请输入内容" clearable style="width:240px">
          </el-input>
        </el-form-item>
        <el-form-item size="small" label="消耗凭证" class="noselect" style="margin-right:300px;position:relative">
          <span style="color:red;position:absolute;left:-77px">*</span>
          <el-upload
          required
            class="avatar-uploader"
            action=''
            :show-file-list="false"
            :auto-upload="false"
            :on-change="getFile">
            <img v-if="imageUrl" :src="imageUrl" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
          <el-button size="small" type="primary" @click="submitForm_pic('new_form')" class="formSubmitBtn" style="margin-right: 340px;">申 报</el-button>
      </el-form>
    </el-dialog>

    <!--批量设置表单  -->
    <el-dialog :visible.sync="multiple_form_dialogVisible" width="600px" label-width="80px">
      <el-form  ref="multiple_form" :model="multiple_form" label-width="80px" label-position="right">
        <el-form-item size="small" label="项目" class="noselect" style="margin-right:240px">
          <el-select  v-model="multiple_form.multipleProject" placeholder="筛选" clearable>
            <el-option v-for="item in chooseProject" :key="item" :label="item" :value="item"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item size="small" label="消耗金额" class="noselect" style="margin-right:240px">
          <el-input v-model="multiple_form.multipleAmount"></el-input>
        </el-form-item>
          <el-button size="small" type="primary" @click="submitMulipleChange" class="formSubmitBtn" style="margin-right: 340px;">确 定</el-button>
      </el-form>
    </el-dialog>
  </div>

</template>

<script>
  import utils from '../utils'
  export default {
    data() {
      return {
        showIf: true,
        // 批量选中的项目
        multipleSelection_delete:'',
        multiple_form_dialogVisible: false,
        // 批量设置输入框内容
        multiple_form: {
          multipleProject: '',
          multipleAmount: ''
        },
        // 表格图片
        url: require('../assets/logo.png'),
        srcList: [
          'https://fuss10.elemecdn.com/8/27/f01c15bb73e1ef3793e64e6b7bbccjpeg.jpeg',
          'https://fuss10.elemecdn.com/1/8e/aeffeb4de74e2fde4bd74fc7b4486jpeg.jpeg'
        ],
        //表单图片
        imageUrl: '',
        imageUrl_edit: '',
        // 搜索栏选项
        chooseAccount: [],
        // 新建表单
        new_form_dialogVisible: false,
        new_form: {
          new_form_date: null,
          new_form_project: null,
          new_form_account: null,
          new_form_id: null,
          new_form_currency: null,
          new_form_amount: null,
          new_form_remarks: null,
          new_form_declareDate: null,
          proofImage : '',
        },
        // 编辑表单
        chooseProject: ["COD/AK/日本/黑五","COD/AK/台湾/黑五","COD/AK/香港/黑五","COD/AK/马来/黑五","COD/AK/新加坡/黑五","COD/AK/菲律宾/黑五","COD/AK/泰国/黑五"],
        edit_form: {
          remarks:null,
          project:null,
          amount:null,
          _id: null,
          proofImage: ''
        },
        edit_form_dialogVisible: false,
        // 序号
        pageIndex:1,
        pagesize:1,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载界面显示与否
        loading: true,
        // 过滤后数据
        ShowTableData: [],
        // 原始数据
        tableData: [],
        // 搜索输入框记录
        searchAccount:'',
        //校验规则
        rules: {
          // 申请账号校验规则
          new_form_date: [
            { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
          ],
          new_form_account: [
            { required: true, message: '请输入账户', trigger: 'change' }
          ],
          new_form_id: [
            { required: true, message: '请输入ID', trigger: 'change' }
          ],
        }
      }
    },

    created() {
      // 执行网络请求
      setTimeout(()=> {
        this.fetch()
      },1000)
      // this.fetch()
    },

    methods: {
      //--------------------------------------------------------------
      // 颜色设置
      setCellColor({row,column,rowIndex,columnIndex}){
        // if(columnIndex===6 || columnIndex===7 || columnIndex===8){
        //   return 'color:#239ce6;';
        // }
        if(columnIndex===6){
          return 'box-shadow: rgb(0 21 41 / 8%) -5px 0px 2px;';
        }
      },
      getRowClass ({ columnIndex }) {
        if(columnIndex===6){
          return 'box-shadow: rgb(0 21 41 / 8%) -5px 0px 2px;';
        }
      },
      //--------------------------------------------------------------
      // 批量选中(待添加async await)
      handleSelectionChange_delete(val) {//有选中项目时触发
        if (val != '') {
          this.showIf = false
        } else {
          this.showIf = true
        }
          console.log(val);
          this.multipleSelection_delete = val;
          this.multipleSelectionFlag_delete = true;
          if (this.multipleSelection_delete.length == 0) {   
            // 如不进行判断则勾选完毕后批量删除按钮还是会在
            this.multipleSelectionFlag_delete = false;
          }
      },
      // 批量设置
      submitMulipleChange() {
        console.log(this.multiple_form.multipleProject);
        this.multipleSelection_delete.forEach((e) => {
          e.project = this.multiple_form.multipleProject
          e.amount   = this.multiple_form.multipleAmount
        })
        this.multiple_form_dialogVisible = false
      },
      //批量申报
      multiple_form_submit() {
        // 数据提交
        var multiple_submit_if = []
        this.multipleSelection_delete.forEach(item => {
          multiple_submit_if.push(item.project)
          multiple_submit_if.push(item.amount)
        })
        if (multiple_submit_if.indexOf('') !== -1) {
          this.$message.error('请检查选中项目的申报信息是否填写完整');
        } else {
          this.$message.success('已申报');
          console.log(this.multipleSelection_delete);
        }
      },
      // 图片上传相关
      getFile(file) {
        console.log(file);
        var isJPG_PNG = ['image/jpeg','image/png']
        var jin = isJPG_PNG.indexOf(file.raw.type) !== -1
        // const isLt2M = file.size / 1024 / 1024 < 2;
        if (!jin) {
          this.$message.error('上传图片只能是 JPG/PNG 格式!');
        }
        else {
        this.handleAvatarSuccess(file)
        this.getBase64(file.raw).then(res => {
            const params = res.split(',')
            console.log(params, 'params')
            if (params.length > 0) {
              this.new_form.proofImage = params[1]
            }
          })
        }
      },
        getFile_edit(file) {
        console.log(file);
        var isJPG_PNG = ['image/jpeg','image/png']
        var jin = isJPG_PNG.indexOf(file.raw.type) !== -1
        // const isLt2M = file.size / 1024 / 1024 < 2;
        if (!jin) {
          this.$message.error('上传图片只能是 JPG/PNG 格式!');
        }
        else {
        this.handleAvatarSuccess_edit(file)
        this.getBase64(file.raw).then(res => {
            const params = res.split(',')
            console.log(params, 'params')
            if (params.length > 0) {
              this.edit_form.proofImage = params[1]
            }
          })
        }
      },
      //显示缩略图
      handleAvatarSuccess(file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      handleAvatarSuccess_edit(file) {
        this.imageUrl_edit = URL.createObjectURL(file.raw);
      },
      // 获取图片转base64
      getBase64(file) {
        return new Promise(function (resolve, reject) {
          const reader = new FileReader()
          let imgResult = ''
          reader.readAsDataURL(file)
          reader.onload = function () {
            imgResult = reader.result
          }
          reader.onerror = function (error) {
            reject(error)
          }
          reader.onloadend = function () {
            resolve(imgResult)
          }
        })
      },
      // 新建表单
      new_form_methods() {
        this.new_form_dialogVisible = true
        this.new_form.new_form_declareDate = new Date().toLocaleDateString()
      },
      //批量表单
      multiple_form_methods() {
        this.multiple_form_dialogVisible = true
      },
      // 编辑表单弹出
      edit_form_methods(e) {
        this.edit_form_dialogVisible = true
        this.edit_form._id = e._id
        this.edit_form.project  = e.project
        this.edit_form.amount = e.amount
      },
      // -----------------------------------------------------------
      //表单提交
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
        });
      },
      // -----------------------------------------------------------
      //表单提交-图片
      submitForm_pic(formName) {
        this.$refs[formName].validate((valid) => {
          if (this[formName].proofImage === '') {
            this.$message.error('请上传消耗凭证');
          } else {
            if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
          }
        });
      },
      //--------------------------------------------------------------
      // 搜索-顺序执行筛选方法数组中的方法(input框code为0;日期筛选code为1,无code默认为下拉筛选框)
      utils_run() {
        var _this = this
        this.ShowTableData = this.tableData// 触发搜索前重新赋值原始数据
        utils.multiplexFilter(_this,this.searchAccount, 'account')
      },
      //--------------------------------------------------------------
      // 数据获取
      fetch() {
        this.$http.get('/consumptiondeclaration.json').then((res) => {// 获取数据

        this.tableData = res.data.consumptiondeclaration//保留原数据
        this.ShowTableData = this.tableData//原数据赋值给展示的表格数据
        
        //根据数据填充下拉选项-账户
        this.tableData.forEach(item => {
          this.chooseAccount.push(item.account)
        })
        this.chooseAccount = [...new Set(this.chooseAccount)]


        //数据完成展示后取消加载页面
        this.loading = false
      })

      },
    },
  }
</script>

<style scoped>
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
      color: rgb(65, 181, 132) !important;
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
  .el-button--primary {
      color: rgb(65, 181, 132) !important;
      background-color: #fff !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(65, 181, 132) !important;
      border-color: rgb(65, 181, 132) !important;
  }
    .el-select {
    display: block!important;
  }
  .el-date-editor.el-input {
    width: 240px!important;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: rgb(65, 181, 132);
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
    .el-button--info {
      color: #606266 !important;
      background-color: #fff !important;
      border-color: rgb(220, 223, 230) !important;
  }
  .el-button--info:hover {
    box-shadow: rgb(0 21 41 / 8%) 2px 2px 4px;
  }
</style>
