<template>
  <div class="login-container">
    <el-card class="login-card">
        <div slot="header" class="clearfix">
          <span style="font-size:17px">登陆</span>
        </div>
      <el-form v-loading="loading" :rules="rules" ref="model" :model="model" @submit.native.prevent="submitForm('model')">
        <el-form-item label="账号" prop="uid" style="width:320px;margin-left:18px">
          <el-input v-model="model.uid"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password" style="width:320px;margin-left:18px;position:relative;top:-15px">
          <el-input type="password" v-model="model.password"></el-input>
        </el-form-item>
        <el-form-item style="position: relative;top: -10px;">
          <el-button class="loginBtn" type="primary" native-type="submit">登录</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
var reg = new RegExp(/^[a-zA-Z0-9]{1,20}$/)
var validatePass = (rule, value, callback) => {
  if (!reg.test(value)) {
    callback(new Error('输入字母或数字'));
  }  else {
    callback();
  }
};
import crypto from '../crypto.js'
export default {
  data() {
    return {
      loading:false,
      rules: {
        password: [
            { validator: validatePass, trigger: 'blur' }
        ],
        uid: [
            { validator: validatePass, trigger: 'blur' }
        ]
      },
      model: {
        password:null,
        uid:null
      },
    };
  },
  methods: {
    async login() {
      this.loading = true
      let formData = new FormData()
      formData.append("name",this.model.uid)
      formData.append("password",this.model.password)
      await this.$http.post('/index.php/index/login/index/',formData).then((res) => {// 获取数据
      if (res.data["code"] === 200) {
        localStorage.setItem('token', res.data["token"])
        this.loading = false
        this.$message.success('登陆成功');
        localStorage.setItem('uid',res.data["data"]["uid"])
        var zh_name = crypto.cryptoEncrypt_string(res.data["data"]["zh_name"])
        localStorage.setItem('zh_name',zh_name)
        var authority = crypto.cryptoEncrypt_string(res.data["data"]["content"])
        localStorage.setItem('authority',authority)
        this.$router.push('/main')
      } else {
        this.loading = false
        this.$message.error('登陆失败');
      }
        //var role = crypto.cryptoEncrypt_string(res.data[0]["role"])//获取到角色并加密保存到localStorage
        //localStorage.setItem('role',role)
        //var menustringify = crypto.cryptoEncrypt_json(res.data)//获取到菜单并加密保存到localStorage
        //localStorage.setItem('menu',menustringify)
      })
      // .then(()=> {
        // this.$router.push('/main')
      // })
    },
    submitForm(formName) {//表单提交
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.login()
        } else {
          return false;
        }
      });
    },
  },
};
</script>

<style scoped>
.el-button--primary {
    color: white;
    background-color: rgb(53, 54, 57);
    border-color: rgb(53, 54, 57);
}
.login-card {
  position: absolute;
  width: 400px;
  height: 340px;
  top: 20%;
  left: 0;
  right: 0;
  margin: auto;
}
.loginBtn:hover {
  background-color: #4D4D4D!important;
  color: white!important;
}
.el-card__header {
  font-size: 30px!important ;
}
</style>
