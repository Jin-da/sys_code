<template>
  <div>
    <!-- 搜索框 -->
    <div style=" display: flex;position:relative;margin-left: 30px;">
      <el-form size="mini" :inline="true" class="demo-form-inline" style="display:flex;flex-wrap:wrap">
        <el-form-item class="noselect" label="账户名称">
          <el-input @change="utils_run" v-model="searchName" placeholder="请输入内容" clearable style="height: 32px">
          </el-input>
        </el-form-item>
        <el-form-item class="noselect" label="账号ID">
          <el-input @change="utils_run" v-model="searchId" placeholder="请输入内容" clearable style="height: 32px">
          </el-input>
        </el-form-item>
        <el-form-item class="noselect" label="信用卡号">
          <el-input @change="utils_run" v-model="searchCardNumber" placeholder="请输入内容" clearable style="height: 32px">
          </el-input>
        </el-form-item>
      </el-form>
    </div>

    <!-- 表格 -->
    <el-table stripe v-loading="loading" element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255,0.9)" ref="multipleTable" :data="ShowTableData" tooltip-effect="dark" style="width: calc(100% - 60px); line-height: 30px; margin:30px;margin-top: 0" border><!--@selection-change="handleSelectionChange_delete"-->
      <el-table-column prop="name" label="账户名称" width="400px">
      </el-table-column>
      <el-table-column prop="id" label="账号ID" width="300px">
      </el-table-column>
      <el-table-column prop="cardnumber" label="信用卡号" width="300px">
      </el-table-column>
      <el-table-column prop="balance" label="余额" width="300px">
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="300px">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-plus" size="small" @click="range(scope.row)">充值</el-button><!--scope.row表示当前行的数据-->
        </template>
      </el-table-column>
    </el-table>

    <!-- 充值表单 -->
    <el-dialog :visible.sync="range_form_dialogVisible" width="500px">
      <el-form ref="range_form" :model="range_form" label-width="100px" label-position="right">

        <el-form-item label-width="150px" style="position:relative">
          <label style="width:200px!important" slot="label">{{'本次可充值额度: $' + this.RechargeLimit}}</label>
          <el-input-number style="position:absolute;left:0" v-model="range_form.rangelimit" controls-position="right" :min="1" :max="RechargeLimit"></el-input-number>
        </el-form-item>
                <el-button size="small" type="primary" @click="submitForm('range_form')" class="formSubmitBtn" style="margin-right: 380px;">确 定</el-button>
      </el-form>

    </el-dialog>

    <!-- 分页 -->
    <div class="block" style="position: relative;right:0px;margin-bottom: 80px">
      <el-pagination
        :current-page="currentPage4"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400">
      </el-pagination>
    </div>
  </div>

</template>

<script>
  import utils from '../utils'//引入过滤方法
  export default {
    data() {
      return {
        // 充值限额
        RechargeLimit: null,
        range_form_dialogVisible: false,
        // 分页
        currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4,
        // 加载界面显示与否
        loading: true,
        // 过滤后数据
        ShowTableData: [],
        // 原始数据
        tableData: [],
        // 搜索输入框记录
        searchName: '',
        searchCardNumber: '',
        searchId:'',
        // 充值表单数据
        range_form: {
          rangelimit: null
        }
      }
    },

    created() {
      // 执行网络请求
      setTimeout(()=> {
        this.fetch()
      },1000)
    },

    methods: {
      //表单提交
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            //发送请求
            console.log(this[formName]);
            this[formName+'_dialogVisible'] = false
            // this.range_form.rangelimit = null//待接口写入then
            // this.$refs[formName].resetFields();//用于清空表单，待接口，写入.then
            // alert('提交成功');
          } else {
            return false;
          }
        });
      },
      // 充值
      range(e) {
        console.log(e);
        this.RechargeLimit = e.RechargeLimit
        this.range_form_dialogVisible = true
      },
      //--------------------------------------------------------------
      // 搜索-顺序执行筛选方法数组中的方法(input框code为0;日期筛选code为1,无code默认为下拉筛选框)
      utils_run() {
        var _this = this
        this.ShowTableData = this.tableData// 触发搜索前重新赋值原始数据
        utils.multiplexFilter(_this,this.searchId, 'id', 0)
        utils.multiplexFilter(_this,this.searchName, 'name', 0)
        utils.multiplexFilter(_this,this.searchCardNumber, 'cardnumber', 0)
      },
      //--------------------------------------------------------------
      // 数据获取
      fetch() {
        this.$http.get('/creditcard.json').then((res) => {// 获取数据
        this.tableData = res.data.creditcardTableData//保留原数据
        this.ShowTableData = this.tableData//原数据赋值给展示的表格数据
        //数据完成展示后取消加载页面
        this.loading = false
      })

      },
      //--------------------------------------------------------------
    },
  }
</script>

<style scoped>
  .is-active {
    background-color: white!important;
  }
  .el-select-dropdown__item.selected {
      color: rgb(65, 181, 132) !important;
      font-weight: 700;
  }
  .el-main {
        line-height: 20px!important;
  }
  .el-button--primary {
      color: rgb(65, 181, 132) !important;
      background-color: #fff !important;
      border-color: rgb(65, 181, 132) !important;
  }

  .el-button--primary:hover {
      color: white !important;
      background-color: rgb(65, 181, 132) !important;
      border-color: rgb(65, 181, 132) !important;
  }

</style>
