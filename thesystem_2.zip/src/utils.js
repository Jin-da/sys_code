export default {
  // 搜索的通用方法
  multiplexFilter(_this, value, params, code) {
    if (value === '') {//
    } else if (code === 1) {
      value = value.split(',')
      _this.ShowTableData = _this.ShowTableData.filter(item => {
        return item[params] >= value[0] && item[params] <= value[1];
      })
    } else if (code === 0) {//模糊搜索
      _this.ShowTableData = _this.ShowTableData.filter(item => {
        return item[params].indexOf(value) !== -1
      })
    } else {//下拉栏搜索
      _this.ShowTableData = _this.ShowTableData.filter(item => {
        return item[params] === value
      })
    }
  },
  multiplexFilter1(_this, value, params, code) {
    if (value === '') {
      //
    } else if (code === 0 && value != '') {//模糊搜索
      _this.ShowTableData = _this.ShowTableData.filter(item => {
        return item['content'][params].indexOf(value) !== -1
      })
    } else if (code === 2 && value != '') {//下拉栏搜索
      _this.ShowTableData = _this.ShowTableData.filter(item => {
        return item['content'][params] === value
      })
    }
  },
  //日期处理(当有日期筛选时需要使用)
  dateToString(_this) {
    if (_this.searchDate instanceof Array) {
      _this.middleSearchDate = _this.searchDate.toString()
    }
    if (_this.searchDate === null) {
      _this.middleSearchDate = ''
      _this.searchDate = []
    }
  },
  getLocalTime(nS) {// 十位时间戳转换
    let time = new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/, ' ').replace(/\//g, '-');
    let space_position = time.indexOf(' ');
    return time.slice(0, space_position);
  },
  deepClone(obj) {//深拷贝
    let _obj = JSON.stringify(obj)
    return JSON.parse(_obj);
  }
}

// var reg = new RegExp(/^[a-zA-Z0-9]{1,5}$/)
// var reg2 = new RegExp(/^[a-zA-Z0-9]{1,20}$/)
// var validatePass = (rule, value, callback) => {
//   if (value === null || value === '') {
//     callback(new Error('二级域名必填'));
//   }
//   if (!reg.test(value)) {
//     callback(new Error('输入五位字母数字'));
//   }  else {
//     callback();
//   }
// };
