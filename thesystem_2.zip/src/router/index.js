import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
// import crypto from '../crypto.js'
// const DepartmentManagement = () => import(/* webpackChunkName: "group-foo" */ '../components/DepartmentManagement.vue')
// const RoleManager = () => import(/* webpackChunkName: "group-foo" */ '../components/RoleManager.vue')
// const AuthorityManagement = () => import(/* webpackChunkName: "group-foo" */ '../components/AuthorityManagement.vue')
// const ChangePassword = () => import(/* webpackChunkName: "group-foo" */ '../components/ChangePassword.vue')
// const EmployeeList = () => import(/* webpackChunkName: "group-foo" */ '../components/EmployeeList.vue')
// const MemberManagement = () => import(/* webpackChunkName: "group-foo" */ '../components/MemberManagement.vue')
const AccountTable = () => import(/* webpackChunkName: "group-foo" */ '../components/AccountTable.vue')
// const AllocationSettings = () => import(/* webpackChunkName: "group-foo" */ '../components/AllocationSettings.vue')
// const MyAccount = () => import(/* webpackChunkName: "group-foo" */ '../components/MyAccount.vue')
// const RecyclingApproval = () => import(/* webpackChunkName: "group-foo" */ '../components/RecyclingApproval.vue')
// const AccountStatistics = () => import(/* webpackChunkName: "group-foo" */ '../components/AccountStatistics.vue')
// const TakeNumberRecord = () => import(/* webpackChunkName: "group-foo" */ '../components/TakeNumberRecord.vue')
// const ImportLog = () => import(/* webpackChunkName: "group-foo" */ '../components/ImportLog.vue')
const Login = () => import(/* webpackChunkName: "group-foo" */ '../components/Login.vue')
const To404 = () => import(/* webpackChunkName: "group-foo" */ '../components/404.vue')
const Main = () => import(/* webpackChunkName: "group-foo" */ '../components/Main.vue')
// const CreditCardNumber = () => import(/* webpackChunkName: "group-foo" */ '../components/CreditCardNumber.vue')
// const ConsumptionDeclaration = () => import(/* webpackChunkName: "group-foo" */ '../components/ConsumptionDeclaration.vue')
// const MyConsumption = () => import(/* webpackChunkName: "group-foo" */ '../components/MyConsumption.vue')
// const AdList = () =>import(/* webpackChunkName: "group-foo" */ '../components/AdList.vue')
import AdList from '../components/AdList.vue'
const TynimceEditor = () =>import(/* webpackChunkName: "group-foo" */ '../components/TynimceEditor.vue')
const LandingPageList= () => import(/* webpackChunkName: "group-foo" */ '../components/LandingPageList.vue')
const StockControl= () => import(/* webpackChunkName: "group-foo" */ '../components/StockControl.vue')
const RealmNameList= () => import(/* webpackChunkName: "group-foo" */ '../components/RealmNameList.vue')
const ApplicationRestrictions= () => import(/* webpackChunkName: "group-foo" */ '../components/ApplicationRestrictions.vue')
const RoleList= () => import(/* webpackChunkName: "group-foo" */ '../components/RoleList.vue')
const test= () => import(/* webpackChunkName: "group-foo" */ '../components/test.vue')
const UserList= () => import(/* webpackChunkName: "group-foo" */ '../components/UserList.vue')
const ServiceList= () => import(/* webpackChunkName: "group-foo" */ '../components/ServiceList.vue')
const ExaminedPageList= () => import(/* webpackChunkName: "group-foo" */ '../components/ExaminedPageList.vue')
import crypto from '../crypto.js'
Vue.use(VueRouter)

//用于避免有冗余路由操作时报错：NavigationDuplicated: Avoided redundant navigation to current location
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

const routes = [
  {
    path: '/home',
    name: 'Home',
    component: Home,
    meta: {
      keepAlive: true,
      roles: ['admin', 'user']
    },
    // 默认的显示标签
    // redirect: '/main',
    children: [
      //首页
      { path: '/main', component: Main, name: '首页'},
      //广告列表
      { path: '/adlist', component: AdList, name: '广告列表'},
      // 域名列表
      { path: '/realmnamelist', component: RealmNameList, name: '域名列表'},
      { path: '/stockcontrol', component: StockControl, name: '库存管理'},
      { path: '/applicationrestrictions', component: ApplicationRestrictions, name: '申请限制'},
      // 账号
      { path: '/accounttable', component: AccountTable, name: '账号列表'},
      // 客服
      { path: '/serviceList', component: ServiceList, name: '客服列表'},
      // 落地页
      { path: '/landingpagelist', component: LandingPageList, name: '落地页列表'},
      { path: '/tynimceeditor', component: TynimceEditor, name: '页面制作'},
      // 审核页
      { path: '/examinedpagelist', component: ExaminedPageList, name: '审核页列表'},
      // 用户
      { path: '/rolelist', component: RoleList, name: '角色列表'},
      { path: '/test', component: test, name: 'test'},
      { path: '/userlist', component: UserList, name: '用户列表'},
    ],

  },
  {
    path: '/',
    name: 'Login',
    component: Login,
    meta: {
      roles: ['admin', 'user']
    },
  },
  {
    path: '/404',
    name: 'To404',
    component: To404,
    meta: {
      roles: ['user', 'admin']
    }
  },
  {path:'*',redirect: "/404"},
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
if (to.path === '/') {//快捷登陆
  if (localStorage.getItem('token') && localStorage.getItem('token') !='' ) {
    next({ path: '/main' })
  } else {
    next()
  }
} else {//进入其他页面
  // ↑插入if中写else
  if (localStorage.getItem('token') !='' && localStorage.getItem('token')) {
  // var authority = crypto.cryptoDecrypt_string(localStorage.getItem('authority'))
  // authority = authority +',main,404'
  // console.log('子组件页面权限',authority);
  // if (authority.indexOf('main') === -1 ) {//权限列表及变量确定后，to.path动态获取(pageA)进行比对
  //   console.log('侧边栏没有该页面，但通过地址栏进入，且没有该页面的权限');
  //   next({ path: '/404' })
  // } else {
    next()
    // }
  } else {
    next({ path: '/' })
  }
}
})
export default router
