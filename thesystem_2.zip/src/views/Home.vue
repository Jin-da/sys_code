<template>
    <el-container>
      <!-- 侧边栏 -->
      <el-aside width="auto">
        <el-menu
          unique-opened
          :default-active="$route.path"
          router
          :collapse="isCollapse"
          class="el-menu-vertical-demo noselect"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#fff"
        >
          <!-- 根据后端返回的菜单json动态渲染的菜单 -->
          <!-- || group.name === '首页'-->
          <!-- <template v-for="group in menuList">
            <el-submenu v-if="group.children && group.children.length > 0" :key="group.id" :index="group.id" :id="'b'+group.id">
              <template slot="title">
                <i :class="group.icon"></i>
                <span slot="title">{{group.name}}</span>
              </template>
              <el-menu-item v-for="menu in group.children" :key="menu.id" :index="menu.url">
                <i class="icon iconfont icon-pointer" style="vertical-align: baseline;"/>
                {{menu.name}}
              </el-menu-item>
            </el-submenu>
            <el-menu-item v-else :key="group.id" :index="group.url" :id="'a'+group.id">
              <i :class="group.icon"></i>
              <span slot="title">{{group.name}}</span>
            </el-menu-item>
          </template> -->
          <!-- 前端写死的菜单 -->
            <el-menu-item id="a0" index="/main">
            <i class="el-icon-s-home"></i>
              <span slot="title">首页</span>
            </el-menu-item>

          <el-submenu index="1" v-if="this.menuAuthrity.pageA">
            <template slot="title">
              <i class="iconfont icon-qitaguanggaoshuju aliiconfont"></i>
              <span>广告</span>
            </template>
            <el-menu-item-group>
              <el-menu-item v-if="this.menuAuthrity.pageA" index="/adlist">广告站点列表</el-menu-item>
            </el-menu-item-group>
          </el-submenu>

          <el-submenu index="2">
            <template slot="title">
              <i class="el-icon-set-up"></i>
              <span>域名</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="/realmnamelist">域名列表</el-menu-item>
              <el-menu-item index="/stockcontrol">库存管理</el-menu-item>
              <el-menu-item index="/applicationrestrictions">申请限制</el-menu-item>
            </el-menu-item-group>
          </el-submenu>

          <el-submenu index="3">
            <template slot="title">
              <i class="iconfont icon-user aliiconfont"></i>
              <span>账号</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="/accounttable">账号列表</el-menu-item>
              <el-menu-item index="/consumptiondeclaration">消耗申报</el-menu-item>
              <el-menu-item index="/404">库存管理</el-menu-item>
              <el-menu-item index="/404">申请限制</el-menu-item>
            </el-menu-item-group>
          </el-submenu>

          <el-submenu index="4">
            <template slot="title">
              <i class="el-icon-service"></i>
              <span>客服</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="/serviceList">客服列表</el-menu-item>
              <!-- <el-menu-item index="/404">客服管理</el-menu-item> -->
            </el-menu-item-group>
          </el-submenu>

          <el-submenu index="5">
            <template slot="title">
              <i class="el-icon-document"></i>
              <span>落地页</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="/landingpagelist">落地页列表</el-menu-item>
              <el-menu-item index="/tynimceeditor">页面制作</el-menu-item>
              <!-- <el-menu-item index="/404">落地页管理</el-menu-item> -->
              <el-menu-item index="/404">数据展示</el-menu-item>
            </el-menu-item-group>
          </el-submenu>

          <el-submenu index="6">
            <template slot="title">
              <i class="el-icon-document-remove"></i>
              <span>审核页</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="/examinedpagelist">审核页列表</el-menu-item>
              <!-- <el-menu-item index="/404">审核页管理</el-menu-item> -->
            </el-menu-item-group>
          </el-submenu>

          <el-submenu index="7">
            <template slot="title">
              <i class="el-icon-user"></i>
              <span>用户</span>
            </template>
            <el-menu-item-group>
              <el-menu-item index="/userlist" v-if="menuAuthrity.pageA">用户列表</el-menu-item>
              <el-menu-item index="/rolelist" v-if="menuAuthrity.pageB">角色列表</el-menu-item>
              <el-menu-item index="/test">test</el-menu-item>
            </el-menu-item-group>
          </el-submenu>

        </el-menu>
      </el-aside>

      <!-- 固定的顶部及主内容 -->
      <el-main style="padding: 0px;position:relative">
        <!-- 首行顶部(侧边栏展示效果及账号的管理) -->
        <el-header class="noselect" style="text-align: right;font-size: 12px;padding-right: 20px;box-shadow: rgb(0 21 41 / 8%) 0px 1px 4px;height: 46px;position: fixed; width: 100%;z-index: 5">
          <div style="font-size: 20px; color: rgb(144, 147, 153)">
            <!-- 侧边栏展示效果按钮 -->
            <i id="menuClose" :class="{ 'iconfont icon-zhankai': isCollapse, 'iconfont icon-shousuo': !isCollapse}" style="height: 55px;font-size: 20px;position: absolute; left: 15px; top: -9px;  color: white!important;" @click="openclose"></i>
          </div>

          <el-tabs v-model="activeIndex" type="card" editable @tab-click="tabClick" @tab-remove="tabRemove" style="margin-left:30px;position:relative;bottom:5px;margin-right:270px;">
            <!-- 单标签 -->
            <el-tab-pane :key="item.name" v-for="item in openTab" :label="item.name" :name="item.route">
            </el-tab-pane>
          </el-tabs>
          
          <!-- 右侧账户管理 -->
          <el-dropdown size="small" trigger="click" style="position: fixed;right: 15px;top:-10px;height:50px">
            <i class="el-icon-arrow-down" style="margin-right: 15px"></i>
            <el-dropdown-menu  slot="dropdown">
              <el-dropdown-item id="logout" style="color:black;background-color:white" @click.native="logout_submit">退出登录</el-dropdown-item>
            </el-dropdown-menu>
            <span>{{zh_name}}</span>
          </el-dropdown>
          
        </el-header>
        
        
        <!-- 标签页标签的存放 实现类似于浏览器保留先前页面的功能 -->
        <!-- <el-header class="noselect" style="box-shadow: rgb(0 21 41 / 8%) 0px 1px 4px; padding-left: 10px;position: fixed; width: 100%;top: 50px;z-index: 4"> -->
          <!-- 标签行 -->
          <!-- <el-tabs v-model="activeIndex" type="card" editable @tab-click="tabClick" @tab-remove="tabRemove"> -->
            <!-- 单标签 -->
            <!-- <el-tab-pane :key="item.name" v-for="item in openTab" :label="item.name" :name="item.route">
            </el-tab-pane>
          </el-tabs> -->
        <!-- </el-header> -->
        
        <!-- 页面组件的插入位置 -->
        
          <transition name="el-fade-in-linear">
            <keep-alive>
            <router-view v-show="show" style="margin:80px 30px 0 30px;"></router-view>
            </keep-alive>
          </transition>
        
        
      </el-main>
    </el-container>
</template>

<script>
import crypto from '../crypto.js'
export default {
  data() {
    return {
      menuAuthrity:{
        "pageA":false,
        "pageB":true
      },
      uid:null,
      zh_name:null,
      authority:null,
      show: true,
      isCollapse: false,
      activeName: "second",
      menuList: []
    };
  },

  // beforeRouteEnter(to,from,next) {
  //   next(vm=> {
  //     console.log('父组件首次获取权限');
  //     var zh_name = localStorage.getItem('zh_name')
  //     var authority = localStorage.getItem('authority')
  //     vm.$store.commit('storeZhname', zh_name);
  //     vm.$store.commit('storeAuthority', authority);
  //   })
  // },

  methods: {
    async logout_submit() {
      let formData = new FormData()
      formData.append("uid",this.uid)
      await this.$http.post('/index.php/index/login/logout/',formData).then((res) => {
        if (res.data["code"] === 200) {
          localStorage.removeItem('token')
          localStorage.removeItem('uid')
          localStorage.removeItem('zh_name')
          localStorage.removeItem('authority')
          this.$router.push('/')
          this.$message.success(`${res.data["data"]}`)
        } else {
          this.$message.error(`${res.data["data"]}`)
        }
      })
    },
    getUserInfo() {
      this.$store.commit("delete_all_tabs");// 清空所有标签避免回退时创建重复标签
      this.$store.commit("add_tabs", { route: this.$route.path, name: this.$route.name });
      this.$store.commit("set_active_index", this.$route.path);
      this.zh_name = crypto.cryptoDecrypt_string(localStorage.getItem('zh_name'))
      this.authority = crypto.cryptoDecrypt_string(localStorage.getItem('authority'))
      this.uid = localStorage.getItem('uid')
        console.log('该用户拥有的权限列表：',this.authority);
        for (const key in this.menuAuthrity) {
          if (this.authority.indexOf(key) != -1 ) {
            console.log('与页面权限总表对应的权限：',key);
            this.menuAuthrity[`${key}`] = true
          }
        }
    },
    openclose() {
      if (this.isCollapse === true) {
        this.isCollapse = false;
      } else {
        this.isCollapse = true;
      }
    },
    handleTabsEdit(targetName, action) {
      if (action === "add") {
        let newTabName = ++this.tabIndex + "";
        this.editableTabs.push({
          title: "New Tab",
          name: newTabName,
          content: "New Tab content",
        });
        this.editableTabsValue = newTabName;
      }
      if (action === "remove") {
        let tabs = this.editableTabs;
        let activeName = this.editableTabsValue;
        if (activeName === targetName) {
          tabs.forEach((tab, index) => {
            if (tab.name === targetName) {
              let nextTab = tabs[index + 1] || tabs[index - 1];
              if (nextTab) {
                activeName = nextTab.name;
              }
            }
          });
        }

        this.editableTabsValue = activeName;
        this.editableTabs = tabs.filter((tab) => tab.name !== targetName);
      }
    },
    tabClick() {//点击标签时的路由跳转
      this.$router.push({ path: this.activeIndex });
    },
    tabRemove(targetName) {//移除标签
      // if (targetName == "/main") {//保留指定页面
      //   return;
      // }
      if (this.openTab.length === 1) {//保留一个
        return;
      }

      this.$store.commit("delete_tabs", targetName);
      if (this.activeIndex === targetName) {
      // 设置当前激活的路由
        if (this.openTab && this.openTab.length >= 1) {
          this.$store.commit(
            "set_active_index",
            this.openTab[this.openTab.length - 1].route
          );
          this.$router.push({ path: this.activeIndex });
        } 
        else {
          this.$router.push({ path: "/main" });//修改首页
        }
      }
    },
  },

  computed: {
    openTab() {
      return this.$store.state.openTab;
    },

    activeIndex: {
      get() {
        return this.$store.state.activeIndex;
      },
      set(val) {
        this.$store.commit("set_active_index", val);
      },
    },
  },

  watch: {
    $route(to) {
      //判断路由是否已经打开
      //已经打开的 ，将其置为active
      //未打开的，将其放入队列里
      let flag = false;
      for (let item of this.openTab) {
        if (item.name === to.name) {
          this.$store.commit("set_active_index", to.path);
          flag = true;
          break;
        }
      }
      if (!flag) {
        this.$store.commit("add_tabs", { route: to.path, name: to.name });
        this.$store.commit("set_active_index", to.path);
      }
    },
  },

  created() {
    this.getUserInfo()
  },
};
</script>

<style>
.el-loading-spinner .path {
    stroke: rgba(41,42,45,0.4)!important;
}
.el-loading-spinner i {
    color: rgb(25,25,25)!important;
}
  .el-menu-vertical-demo:first-child {
    background-color: rgb(41,42,45)!important;
  }
  .el-submenu__title {
    text-align: left;
    color: #cecece!important;
    background-color: rgb(41,42,45)!important;
  }
  .el-menu-item {
    color: #cecece!important;
    background-color: rgb(53,54,57)!important;
    text-align: left;
    padding-left: 50px!important;
  }
  .el-input__inner:focus {
    border-color: #409EFF !important;
  }
  .el-range-editor.is-active, .el-range-editor.is-active:hover {
    border-color: #409EFF !important;
  }
  .el-pager li.active  {
    color: white;
  }
  .el-pagination.is-background .el-pager li:not(.disabled).active {
    background-color: rgb(77,77,77)!important;
    color: #FFF;
    border-color: rgb(77, 77, 77)!important;
    border: 1px solid;
  }
  .el-dialog {
    border-radius: 4px!important;
  }
  .el-message-box {
    word-wrap:break-word!important;
  }
  .noselect {
    -webkit-touch-callout: none; /* iOS Safari */
    -webkit-user-select: none; /* Chrome/Safari/Opera */
    -khtml-user-select: none; /* Konqueror */
    -moz-user-select: none; /* Firefox */
    -ms-user-select: none; /* Internet Explorer/Edge */
    user-select: none; /* Non-prefixed version, currently not supported by any browser */
  }
  .el-tabs__nav-scroll{
    height: 50px;
  }
  .is-top {
    height: 50px!important;
  }
  .el-tabs__nav-prev,.el-tabs__nav-next {
    top:10px;
  }
  .el-tabs__new-tab {
    display: none;
  }
  .el-tabs__header {
    border-bottom: none !important;
  }
  .el-tabs__item {
    color: #cecece!important;
    position: relative;
    top: 1px;
    height: 34px!important;
    line-height: 31px!important;
    border-left: none!important;
    background-color: rgb(25,25,25);
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
  }
  .el-tabs__item:hover {
    color: #cecece!important;
    cursor: pointer;
  }
  .el-tabs__item.is-active {
    background-color: rgb(77, 77, 77) !important;
    color: white !important;
    box-shadow: none!important;
  }
  .el-tabs__nav {
    border: none !important;
  }
  .el-tabs__content {
    display: none;
  }
  .el-tabs__header {
    border: none;
    margin: 0;
  }
  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
  }
  #menuClose:hover {
    cursor: pointer;
  }
  .el-menu-item-group__title {
    display: none;
  }
  .is-active {
    background-color: rgb(77, 77, 77) !important;
    color: white!important;
    border-bottom-color:rgb(41,42,45)!important;
  }
  .el-header {
    background-color: rgb(25,25,25);
    color: #333;
    text-align: center;
    line-height: 65px;
  }
  .el-aside {
    margin-top: 46px;
    background-color: rgb(41,42,45)!important;
    color: #333;
    text-align: center;
    line-height: 200px;
  }
  .el-main {
    margin-top: 0;
    background-color: #fff;
    color: #333;
    text-align: center;
  }
  .el-container {
    position: absolute;
    width: 100%;
    top: 0px;
    left: 0;
    bottom: 0;
    background-color: rgb(25,25,25)!important;
  }
  .el-header {
    padding: 0;
    /* z-index: 9999!important; */
  }
  .el-header .fr {
    float: right;
  }
  .el-header .el-menu {
    border-bottom: none;
  }
  .el-aside {
    background: #545c64;
  }
  .el-aside .el-menu {
    border-right: none;
  }
  .el-range-separator {
    padding: 0!important;
  }
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    left: -20px!important;
  }
  .avatar-uploader .el-upload:hover {
    border-color: rgb(64,158,255)!important;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
  .el-dropdown {
    color: white!important;
  }
  .el-icon-close:hover {
    line-height: 14px!important;
  }
  .el-icon-close {
    line-height: 14px!important;
  }
  .aliiconfont {
    margin: 0 8px 0 4px;
  }
  .tox .tox-dialog--width-lg {
    height: 650px!important;
    max-width: 810px!important;
  }
    /* .tox .tox-dialog-wrap__backdrop {
      background-color: rgba(128,128,128, 0.8)!important;
    } */
  .cell {
    overflow: hidden!important;
  white-space: nowrap!important;
  text-overflow: ellipsis!important;
  }
  .el-tree-node {
      width: 220px!important;
  }
  .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner {
    background-color: rgba(0,0,0,0)!important;
    border: none!important;
  }
  .el-checkbox__input.is-disabled.is-indeterminate .el-checkbox__inner {
    background-color: rgba(0,0,0,0)!important;
    border: none!important;
  }
  .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner::after{
    border-color: #606266!important;
  }
    .el-checkbox__input.is-disabled.is-indeterminate .el-checkbox__inner::before {
    background-color: #606266!important;  
    }
  #a0 {
    background-color: rgb(41,42,45)!important;
    padding-left: 20px!important;
    text-align: left;
  }
  #logout:hover {
    background-color: #606266!important;
    color: white!important;
  }
  .is-plain {
  background-color: white !important;
  color: #606266 !important;
}
.is-plain:hover {
  background-color: rgb(77, 77, 77) !important;
  border-color: rgb(77, 77, 77) !important;
  color: white !important;
}
.is-plain:disabled {
  background-color: white!important;
  border-color: #DCDFE6!important;
  color: #DCDFE6 !important;
}
.el-table td {
  padding: 10px 0!important;
}
.el-message-box {
      position: relative;
    top: -10%;
}
</style>

