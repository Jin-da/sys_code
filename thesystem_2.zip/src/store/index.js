import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    openTab:[],//所有打开的路由
    activeIndex:'/', //激活状态
    menu: [],//用户权限菜单
    data:{
      content:null,
      filename:null,
      pageName:null,
      pageType:null
    },
    authority:null,
    zh_name:null
  },
  mutations: {
    // 添加tabs
    add_tabs (state, data) {
      this.state.openTab.push(data);
    },
    // 删除tabs
    delete_tabs (state, route) {
      let index = 0;
      for (let option of state.openTab) {
        if (option.route === route) {
          break;
        }
        index++;
      }
      this.state.openTab.splice(index, 1);
    },
    // 设置当前激活的tab
    set_active_index (state, index) {
      this.state.activeIndex = index;
    },
    //将获取到的用户权限菜单json数据存储到vuex里
    storeMenu(state, menu) {
      this.state.menu = menu;
    },
    //存储落地页内容
    storePageContent(state, data) {
      this.state.data = data;
    },
    
    delete_all_tabs(state) {
      state.openTab = []
      // this.state.activeIndex = '/'
    },
    //authority
    storeAuthority(state, data) {
      this.state.authority = data;
    },
    //zh_name
    storeZhname(state, data) {
      this.state.zh_name = data;
    },
  }, 

  actions: {
  },
  modules: {
  }
})
